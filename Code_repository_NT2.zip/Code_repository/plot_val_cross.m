
function []=plot_val_cross(PP,CleanFates,FatesToPlot,col,whichsignals)

% Intensity cross plot by fates - instantenous/transient values

% 
InputMatrix=PP;

% title
ftitle='Cross correlation';
fxlabel='Tg(ptch2:kaede) signal';
fylabel='GFP signal';
% labels

figure;

for i=1:size(FatesToPlot,2)

ind=strcmp(CleanFates,FatesToPlot(i));
FateMatrix=InputMatrix(ind,:,:);
% plot all values between two channels
row=size(FateMatrix,1);
column=size(FateMatrix,2)-1;
signal1=reshape(FateMatrix(:,2:end,whichsignals(1)),[1,row*column]);
signal2=reshape(FateMatrix(:,2:end,whichsignals(2)),[1,row*column]);
plot(signal1,signal2,'.','Color',col(i,:),'MarkerSize',10);
hold on;
end

axis tight

% Create title
title(ftitle,'FontSize',20);

% Create xlabel
xlabel(fxlabel,'FontSize',14);

% Create ylabel
ylabel(fylabel,'FontSize',14);

end