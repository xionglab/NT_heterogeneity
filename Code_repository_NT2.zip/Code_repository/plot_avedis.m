
function out=plot_avedis(X,Y,Z,TimeAxis,col)
% this function plots the average distance between cells over time, a
% measurement of cell density. The input takes in the X,Y,Z coordinate
% matrix and the TimeAxis, the output is plotted by errorbar or shade as
% distance vs time. The plotted results will be stored in an output matrix.
% This makes it possible to do multiple fates with a higher level script.
% col is the plot color.

% Output structure, TimeAxis columns, 3 rows, 1st is TimeAxis, 2nd is
% average distance in um, 3rd is stdev

% title
ftitle='Average Cell-Cell Distances';
% x label
fxlabel='Time (hpf)';
% y label
fylabel='Distance (\mum)';

out=zeros(3,size(TimeAxis,2));
out(1,:)=TimeAxis;

for i=1:size(TimeAxis,2)
    M=Mesh_Distance(X,Y,Z,TimeAxis,TimeAxis(i));
    M(isnan(M))=0;
    M(:,1)=[];
    V=reshape(M,[1,size(M,1)*size(M,2)]);
    out(2,i)=mean(V(V~=0));
    out(3,i)=std(V(V~=0));
end

% to take into account the lengths of different tracks to avoid unfair bias
% in plotting, consider the ave dis to be valid when more than half of the
% meshes were recorded in the input matrix
count=X~=0;
ind=sum(count(:,2:end))./size(count,1)>=0.5;
outplot=out(:,ind);

figure;
errorbar(outplot(1,:),outplot(2,:),outplot(3,:),'LineWidth',2,'Color',col);
   % hold on;
    %fill([out(1,:) fliplr(out(1,:))],[out(1,:)+out(2,:) fliplr(out(1,:)-out(2,:))],col,...
    %'FaceAlpha', alpha,'linestyle','none');

axis tight;

% Create title
title(ftitle,'FontSize',20);

% Create xlabel
xlabel(fxlabel,'FontSize',14);

% Create ylabel
ylabel(fylabel,'FontSize',14);


end

