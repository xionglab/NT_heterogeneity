
% this standalone script makes all plots assuming raw data (NewFinalWrkspace) and All_filters
% data have been loaded

% Define fates to be plotted here and signals to be plotted
FatesToPlot = {'MFP' 'LFP' 'MN' 'DorsalToMN'};
plotnames = {'MFP' 'LFP' 'pMN' 'More dorsal'};
col=[1,0,0;0.87058824300766,0.490196079015732,0;0 1 0;0 0 1];
% colors

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% All plots directly from the workspace
% multiple single traces
multiplot(CleanStitchedTrajs(:,1,1),3,TimePointArrayHPF,CleanStitchedTrajs,CleanFates);
% average position with errorbar automatic scale to notochord time array
aveplot_position(CleanFX_LMDVDistTrajs,NotocordTimesArrayHPF,CleanFates,...
    FatesToPlot,col);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot multiple tracks by position
plot_tracks_pos(CleanFX_DVDistTrajs,NotocordTimesArrayHPF,CleanFates,FatesToPlot,col);
plot_tracks_pos(CleanFX_LMDistTrajs,NotocordTimesArrayHPF,CleanFates,FatesToPlot,col);
plot_tracks_pos(CleanFX_LMDVDistTrajs,NotocordTimesArrayHPF,CleanFates,FatesToPlot,col);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot average distance between cells over time, and broken to X,Y,Z
% dimensions. No fate distinguishing
plot_avedis(Clean_X_StitchedTrajs,Clean_Y_StitchedTrajs,Clean_Z_StitchedTrajs,TimePointArrayHPF,[1,0,0]);
plot_avedis_1d(Clean_X_StitchedTrajs,TimePointArrayHPF,[0,1,0],'X');
plot_avedis_1d(Clean_Y_StitchedTrajs,TimePointArrayHPF,[0,1,0],'Y');
plot_avedis_1d(Clean_Z_StitchedTrajs,TimePointArrayHPF,[0,1,0],'Z');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% intensity cross correlations for 0 and modeled
whichsignals = [1,2];
plot_val_cross(M4,CleanFates,FatesToPlot,col,whichsignals);
plot_val_cross(PP,CleanFates,FatesToPlot,col,whichsignals);

for whichsignal = 1:2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot filtering process here
PlotTrajs4(TimePointArrayHPF,M1(:,2:end,whichsignal),'Time(hpf)','Intensity','Satmasked',[],[0 0 204],0);
PlotTrajs4(TimePointArrayHPF,M2(:,2:end,whichsignal),'Time(hpf)','Intensity','BldCorrected',[],[0 0 204],0);
PlotTrajs4(TimePointArrayHPF,M3(:,2:end,whichsignal),'Time(hpf)','Intensity','Smoothened',[],[0 0 204],0);
PlotTrajs4(TimePointArrayHPF,M4(:,2:end,whichsignal),'Time(hpf)','Intensity','Normalized',[],[0 0 204],0);
PlotTrajs4(TimePointArrayHPF,M4_d1(:,2:end,whichsignal),'Time(hpf)','Intensity','1stDeriv',[],[0 0 204],0);
PlotTrajs4(TimePointArrayHPF,M4_d2(:,2:end,whichsignal),'Time(hpf)','Intensity','2ndDeriv',[],[0 0 204],0);    
PlotTrajs4(M0TimeAxis,M0(:,2:end,whichsignal),'Time(hpf)','Intensity','Windowed',[],[0 0 204],0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot multiple tracks by fate, before and after windowing
plot_tracks(CleanStitchedTrajs,TimePointArrayHPF,CleanFates,FatesToPlot,col,whichsignal,'Raw');
plot_tracks(M1,TimePointArrayHPF,CleanFates,FatesToPlot,col,whichsignal,'Satmasked');
plot_tracks(M2,TimePointArrayHPF,CleanFates,FatesToPlot,col,whichsignal,'BldCorrected');
plot_tracks(M3,TimePointArrayHPF,CleanFates,FatesToPlot,col,whichsignal,'Smoothened');
plot_tracks(M4,TimePointArrayHPF,CleanFates,FatesToPlot,col,whichsignal,'Normalized');
plot_tracks(M4_d1,TimePointArrayHPF,CleanFates,FatesToPlot,col,whichsignal,'1stDeriv');
plot_tracks(M4_d2,TimePointArrayHPF,CleanFates,FatesToPlot,col,whichsignal,'2ndDeriv');
plot_tracks(M0,M0TimeAxis,CleanFates,FatesToPlot,col,whichsignal,'Windowed');
plot_tracks(M0_d1,M0TimeAxis,CleanFates,FatesToPlot,col,whichsignal,'1stDeriv');
plot_tracks(M0_d2,M0TimeAxis,CleanFates,FatesToPlot,col,whichsignal,'2ndDeriv');
plot_tracks(PP,TT,CleanFates,FatesToPlot,col,whichsignal,'Modeled Signaling Level');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% average intensities for 0,1st and 2nd derivatives
aveplot_intensity(M4,TimePointArrayHPF,CleanFates,FatesToPlot,col,plotnames,whichsignal);
aveplot_intensity(M4_d1,TimePointArrayHPF,CleanFates,FatesToPlot,col,plotnames,whichsignal);
aveplot_intensity(M4_d2,TimePointArrayHPF,CleanFates,FatesToPlot,col,plotnames,whichsignal);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% spatial pattern of intensity behaviors
plot_pattern(CleanStitchedTrajs,TimePointArrayHPF,CleanFX_LMDVDistTrajs,NotocordTimesArrayHPF,whichsignal)
plot_pattern(M4,TimePointArrayHPF,CleanFX_LMDVDistTrajs,NotocordTimesArrayHPF,whichsignal);
plot_pattern(PP,TT,CleanFX_LMDVDistTrajs,NotocordTimesArrayHPF,whichsignal);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% max and ave
plot_max(PP,TT,CleanFates,FatesToPlot,col,whichsignal);
plot_ave(PP,TT,CleanFates,FatesToPlot,col,whichsignal);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% time counter
% specify the arbitury threshold
Th=0.05;
plot_times_2(PP,Th,CleanFates,FatesToPlot,col,whichsignal);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% time counter by different ranges
% below inputs are only required for plot_times_3
% specify the arbitury threshold ranges
ThRanges=[0,0.05,0.1,0.15,1];
plot_times_3(PP,ThRanges,CleanFates,FatesToPlot,col,whichsignal);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% time counter by different value ranges split into different time ranges
% below inputs are only required for plot_timedistribution
ValueRanges=[0,0.05;0.05,0.1;0.1,0.15;0.15,1];
% define different ranges here allowing the plotting function to make
% different plots. nX2 matrix, row 1 is the lower bound row 2 is the upper
% bound
TimeRanges=[10,11;11,12;12,13;13,14;14,15];
% this defines the time windows to break plots down to.
plot_timedistribution(PP,TT,TimeRanges,ValueRanges,CleanFates,FatesToPlot,col,whichsignal);

end

