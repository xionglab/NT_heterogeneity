LabelCleanStitchedTrajs = cat(1,TrackIntTrajectoriesHPF(1,:,:),CleanStitchedTrajs);

%----------------------------------------------------------------------------
% Plot all trajectories, loop through 8 colors regardless of fate
%----------------------------------------------------------------------------

for ppp = 1:NoOfSignals
    
    FigTitle(ppp) = strcat('**',Signals(ppp),'** Cell Intensity Trajectories - No Fate');
    
    Fig_TrajsNoFate(ppp) = figure('Name',FigTitle{ppp},'NumberTitle','off');
    
end


for aa = 1:size(CleanStitchedTrajs,1)
    
    xPrelim = [];
    yPrelim = [];
    xFinal = [];
    yFinal = [];
    
    % work with the intensity trajectory data for one cell at a time
    for nnn = 1:NoOfSignals
    % for y data get rid of the first column which is the gofigure track id
    yPrelim(nnn,:) = CleanStitchedTrajs(aa,2:size(CleanStitchedTrajs,2),nnn);
    end
    % for x data get rid of the first column which is a zero (padding to
    % fill the matrix)
    xPrelim = LabelCleanStitchedTrajs(1,2:size(LabelCleanStitchedTrajs,2),1);
    
    % find the first and last nonzero elements in the track data (the start
    % and end of the track)
    [~,StartTraj] = find(yPrelim,1,'first');
    [~,EndTraj] = find(yPrelim,1,'last');
    
     
    xFinal = xPrelim(StartTraj:EndTraj);
    
    
    for ooo = 1:NoOfSignals
     
        yFinal(ooo,:) = yPrelim(ooo,StartTraj:EndTraj);
    
        set(0, 'CurrentFigure', Fig_TrajsNoFate(ooo))
        plot(xFinal,yFinal(ooo,:));
        hold all
    
    
    end
   
    
   
    
end

mkdir('Plots');

for vvv = 1:NoOfSignals
    
    FileName(vvv) = strcat('Plots/',Signals(vvv),'_AllTrajsNoFate.eps');
    saveas(Fig_TrajsNoFate(vvv), FileName{vvv},'epsc');
    
end

FateSet = {'NA' 'MFP' 'LFP' 'MN' 'V2' 'Somite' '10DV' '20DV' '30DV' '40DV' '50DV' '60DV' '70DV' '80DV' '90DV' '100DV'};
% create a set of names for data matrices that will hold fate-specific trajectory
% data for each fate in FateSet - e.g. the V2 data matrix will only hold
% trajectories that have been assigned the V2 fate by the user
%
% save the list of names in FateSpecificDataMatrixNames (horizontal cell)
%
% then initialize those fate-specific data matrices as empty, assigning the
% names generated from the labels in FateSet as these empty matrices
for a = 1:size(FateSet,2)
    CurrentFateSpecificDataMatrixName = ['CleanStitchedTrajs_Fate_',FateSet{a}];
    FateSpecificDataMatrixNames{a} = CurrentFateSpecificDataMatrixName;
    eval([CurrentFateSpecificDataMatrixName,'=[];']); 
    
    CurrentFateSpecific_X_DataMatrixName = ['Clean_X_StitchedTrajs_Fate_',FateSet{a}];
    FateSpecific_X_DataMatrixNames{a} = CurrentFateSpecific_X_DataMatrixName;
    eval([CurrentFateSpecific_X_DataMatrixName,'=[];']); 
    
    CurrentFateSpecific_Y_DataMatrixName = ['Clean_Y_StitchedTrajs_Fate_',FateSet{a}];
    FateSpecific_Y_DataMatrixNames{a} = CurrentFateSpecific_Y_DataMatrixName;
    eval([CurrentFateSpecific_Y_DataMatrixName,'=[];']); 
    
    CurrentFateSpecific_Z_DataMatrixName = ['Clean_Z_StitchedTrajs_Fate_',FateSet{a}];
    FateSpecific_Z_DataMatrixNames{a} = CurrentFateSpecific_Z_DataMatrixName;
    eval([CurrentFateSpecific_Z_DataMatrixName,'=[];']); 
    
    CurrentFateSpecific_LMDV_DataMatrixName = ['Clean_LMDV_StitchedTrajs_Fate_',FateSet{a}];
    FateSpecific_LMDV_DataMatrixNames{a} = CurrentFateSpecific_LMDV_DataMatrixName;
    eval([CurrentFateSpecific_LMDV_DataMatrixName,'=[];']); 
end
% create a 3 column matrix, sets colors for first 6 fates in FateSet in the order in which they appear
% in fate set
% n/a - gray (119 136 153); MFP - cyan (0 255 255); LFP - dark blue (0 0 205); MN - green (34 139 34); V2 - purple (160 32 240); somite - red (255 0 0) 
SolidFateColorSet = [.47 .53 .6;0 1 1;0 0 .8; .13 .55 .13;.63 .13 .94;1 0 0];
% create a 3 column matrix with set of 10 maximally and equally spaced colors for the 10-100% DV
% fates (very subjective) using varycolor 
DVFateColorSet = varycolor(10);
% combine them into a single matrix that holds the rgb colors for all of
% the fates in FateSet - index of the fate in FateSet corresponds to the
% row index of its color in FateColorSet
FateColorSet = vertcat(SolidFateColorSet,DVFateColorSet);
% 'Solid' fates are plotted as solid lines, while DV assigned fates are
% plotted as dots only
FateLineStyleSet = {'-' '-' '-' '-' '-' '-' 'none' 'none' 'none' 'none' 'none' 'none' 'none' 'none' 'none' 'none'};
FateMarkerSet = {'none' 'none' 'none' 'none' 'none' 'none' '.' '.' '.' '.' '.' '.' '.' '.' '.' '.'};

%----------------------------------------------------------------------------
% Plot all trajectories, color corresponds to assigned fate, 'solid' fates are plotted as lines, 'subjective' fates are plotted as filled circles
% Also populate the Fate Specific Data Matrices initialized above
%----------------------------------------------------------------------------

for qqq = 1:NoOfSignals
    
    FigTitle2(qqq) = strcat('**',Signals(qqq),'** Cell Intensity Trajectories - Colored by Fate');
    
    Fig_TrajsColorByFate(qqq) = figure('Name',FigTitle2{qqq},'NumberTitle','off');
    
end


for aa = 1:size(CleanStitchedTrajs,1)
    
    xPrelim = [];
    yPrelim = [];
    xFinal = [];
    yFinal = [];
    
    % work with the intensity trajectory data for one cell at a time
    for rrr = 1:NoOfSignals
    % for y data get rid of the first column which is the gofigure track id
    yPrelim(rrr,:) = CleanStitchedTrajs(aa,2:size(CleanStitchedTrajs,2),rrr);
    end
    % for x data get rid of the first column which is a zero (padding to
    % fill the matrix)
    xPrelim = LabelCleanStitchedTrajs(1,2:size(LabelCleanStitchedTrajs,2),1);
    
    % get the string that specifies the fate of the current intensity
    % trajectory to be plotted
    CurrentManualFate = CleanFates(aa);
    
    % compare the fate string for the current intensity  trajectory to be
    % plotted with the possible fate strings contained in FateSet, when you
    % find the match in FateSet, use it's index to assign the color that
    % should be used for that fate from FateColorSet 
    for ac = 1:size(FateSet,2)
        FindFate = strcmp(CurrentManualFate,FateSet(ac));
        if FindFate == 1
            FindColor = FateColorSet(ac,:);
            FindLine = FateLineStyleSet(ac);
            FindMarker = FateMarkerSet(ac);
            % find the name of the fate specific data matrix that matches the fate for
            % this GoFigure Id
            FindFateSpecificDataMatrixName = FateSpecificDataMatrixNames{ac};
            FindFateSpecific_X_DataMatrixName = FateSpecific_X_DataMatrixNames{ac};
            FindFateSpecific_Y_DataMatrixName = FateSpecific_Y_DataMatrixNames{ac};
            FindFateSpecific_Z_DataMatrixName = FateSpecific_Z_DataMatrixNames{ac};
            FindFateSpecific_LMDV_DataMatrixName = FateSpecific_LMDV_DataMatrixNames{ac};
            % assign the value of that fate specific data matrix to the
            % temporary holding variable CurrentFateSpecificDataMatrix - this variable is
            % first created through this call and the value of this temporary holding variable will change in
            % each iteration of the loop (holding the appropriate fate
            % specific data matrix for the current trajectory being handled
            % in the loop - e.g. it will hold the MN specific data matrix
            % if the current trajectory has been classified as an MN)
            assignin('base','CurrentFateSpecificDataMatrix',eval(FindFateSpecificDataMatrixName));
            assignin('base','CurrentFateSpecific_X_DataMatrix',eval(FindFateSpecific_X_DataMatrixName));
            assignin('base','CurrentFateSpecific_Y_DataMatrix',eval(FindFateSpecific_Y_DataMatrixName));
            assignin('base','CurrentFateSpecific_Z_DataMatrix',eval(FindFateSpecific_Z_DataMatrixName));
            assignin('base','CurrentFateSpecific_LMDV_DataMatrix',eval(FindFateSpecific_LMDV_DataMatrixName));
            % add the current trajectory data to the trajectories already
            % contained in the fate specific data matrix using this
            % temporary holding variable
            CurrentFateSpecificDataMatrix = cat(1,CurrentFateSpecificDataMatrix,CleanStitchedTrajs(aa,:,:));
            CurrentFateSpecific_X_DataMatrix = cat(1,CurrentFateSpecific_X_DataMatrix,Clean_X_StitchedTrajs(aa,:));
            CurrentFateSpecific_Y_DataMatrix = cat(1,CurrentFateSpecific_Y_DataMatrix,Clean_Y_StitchedTrajs(aa,:));
            CurrentFateSpecific_Z_DataMatrix = cat(1,CurrentFateSpecific_Z_DataMatrix,Clean_Z_StitchedTrajs(aa,:));
            CurrentFateSpecific_LMDV_DataMatrix = cat(1,CurrentFateSpecific_LMDV_DataMatrix,LMDVDistTrajs(aa,:));
            % take the now-updated fate specific data matrix held in the temporary holding variable CurrentFateSpecificDataMatrix and use it to update the real fate specific data matrix 
            eval([FindFateSpecificDataMatrixName,'= CurrentFateSpecificDataMatrix;']); 
            eval([FindFateSpecific_X_DataMatrixName,'= CurrentFateSpecific_X_DataMatrix;']);
            eval([FindFateSpecific_Y_DataMatrixName,'= CurrentFateSpecific_Y_DataMatrix;']);
            eval([FindFateSpecific_Z_DataMatrixName,'= CurrentFateSpecific_Z_DataMatrix;']);
            eval([FindFateSpecific_LMDV_DataMatrixName,'= CurrentFateSpecific_LMDV_DataMatrix;']);
            break % if you've already found the matching fate then you can stop looping through FateSet and move on to the next part of the analysis
        end
    end
    
    % find the first and last nonzero elements in the track data (the start
    % and end of the track)
    [~,StartTraj] = find(yPrelim,1,'first');
    [~,EndTraj] = find(yPrelim,1,'last');
    
    
    xFinal = xPrelim(StartTraj:EndTraj);
    
    
    for sss = 1:NoOfSignals
        
        yFinal(sss,:) = yPrelim(sss,StartTraj:EndTraj);
    
        set(0,'CurrentFigure',Fig_TrajsColorByFate(sss));
        
    % assign each of the trajectory plots colored by fate to its own handle
    TrajsColorByFate(aa,sss) = plot(xFinal,yFinal(sss,:));
        
    if strcmp(FindLine,'-') == 1
        
        set(TrajsColorByFate(aa,sss),'LineStyle','-');
        set(TrajsColorByFate(aa,sss),'Color',FindColor);
        set(TrajsColorByFate(aa,sss),'LineWidth',1.8);
        set(TrajsColorByFate(aa,sss),'Visible','on');
        
    elseif strcmp(FindMarker,'.') == 1
        
        set(TrajsColorByFate(aa,sss),'LineStyle','none');
        set(TrajsColorByFate(aa,sss),'Marker','.');
        set(TrajsColorByFate(aa,sss),'MarkerEdgeColor',FindColor);
        set(TrajsColorByFate(aa,sss),'MarkerFaceColor',FindColor);
        set(TrajsColorByFate(aa,sss),'MarkerSize',8);
        set(TrajsColorByFate(aa,sss),'Visible','on');
        
    end
    
    hold on
    
    end
        
end

for vvv = 1:NoOfSignals
    
    FileName(vvv) = strcat('Plots/',Signals(vvv),'_AllTrajsColorByFate.eps');
    saveas(Fig_TrajsColorByFate(vvv), FileName{vvv},'epsc');
    
end

%----------------------------------------------------------------------------
% Calculate 'average' trajectories and trajectory stdevs for each fate 
%----------------------------------------------------------------------------
for b = 1:size(FateSpecificDataMatrixNames,2)
    % loop through the fate specific data matrix names, in the loop for
    % each one, get out the data associated with that name and assign it to
    % CurrenFateSpecificDataMatrix to work with the data
    CurrentFateSpecificDataMatrixName = FateSpecificDataMatrixNames{b};
    assignin('base','CurrentFateSpecificDataMatrix',eval(CurrentFateSpecificDataMatrixName));
    
    CurrentFateSpecific_LMDV_DataMatrixName = FateSpecific_LMDV_DataMatrixNames{b};
    assignin('base','CurrentFateSpecific_LMDV_DataMatrix',eval(CurrentFateSpecific_LMDV_DataMatrixName));
    % check if the current fate specific data matrix is empty, if it is,
    % put placeholder arrays of ones in the matrices holding fate specific ave and stdev data 
    CheckEmpty = isempty(CurrentFateSpecificDataMatrix);
    if CheckEmpty == 1
      FateSpecificAverageData(b,:,:) = ones(1,(size(CleanStitchedTrajs,2))-1,NoOfSignals);
      FateSpecificStdevData(b,:,:) = ones(1,(size(CleanStitchedTrajs,2))-1,NoOfSignals); 
      
      FateSpecificAverage_LMDV_Data(b,:) = ones(1,(size(LMDVDistTrajs,2))-1);
      FateSpecificStdev_LMDV_Data(b,:) = ones(1,(size(LMDVDistTrajs,2))-1); 
    else
      % strip away GoFigure trajectory labels to calculate mean,sd,etc
      CurrentFateSpecificDataMatrixStripped = CurrentFateSpecificDataMatrix(:,2:size(CurrentFateSpecificDataMatrix,2),:);
      CurrentFateSpecific_LMDV_DataMatrixStripped = CurrentFateSpecific_LMDV_DataMatrix(:,2:size(CurrentFateSpecific_LMDV_DataMatrix,2));
      % replace zeros in the current data matrix with NaNs in order to
      % calculate stdev while ignoring zero values
      CurrentFateSpecificDataMatrixStripped(CurrentFateSpecificDataMatrixStripped==0)=NaN;
      CurrentFateSpecific_LMDV_DataMatrixStripped(CurrentFateSpecific_LMDV_DataMatrixStripped==0)=NaN;
      % initialize and populate a matrix that holds the average data trajectories for each
      % of the fates in their own row, data starts with the first column (eg
      % the first column is NOT a label in these matrices) - average is
      % calculated without aligning data in any way, but does ignore zeros
      FateSpecificAverageData(b,:,:) = nanmean(CurrentFateSpecificDataMatrixStripped,1);
      FateSpecificAverage_LMDV_Data(b,:) = nanmean(CurrentFateSpecific_LMDV_DataMatrixStripped,1);
      % and one that holds the stdev data for those average trajectories, 
      FateSpecificStdevData(b,:,:) = nanstd(CurrentFateSpecificDataMatrixStripped,[],1); 
      FateSpecificStdev_LMDV_Data(b,:) = nanstd(CurrentFateSpecific_LMDV_DataMatrixStripped,[],1);
    end
       
    
end

%----------------------------------------------------------------------------
% Plot fate-specific average trajectories together on a single plot w and wo stdevs
%----------------------------------------------------------------------------

for qqq = 1:NoOfSignals
    
    FigTitle6(qqq) = strcat('**',Signals(qqq),'** Fate-specific Average Intensity Trajectories');
    FigTitle7(qqq) = strcat('**',Signals(qqq),'** Fate-specific Average Intensity Trajectories');
    
    Fig_FateSpecAveTrajs(qqq) = figure('Name',FigTitle6{qqq},'NumberTitle','off');
    Fig_FateSpecAveTrajs_Stdev(qqq) = figure('Name',FigTitle7{qqq},'NumberTitle','off');
    
end


for ac = 1:size(FateSpecificAverageData,1)
    
    xPrelim = [];
    yPrelim = [];
    stdevPrelim = [];
    xFinal = [];
    yFinal = [];
    stdevFinal = [];
    
    for rrr = 1:NoOfSignals
        
        yPrelim(rrr,:) = FateSpecificAverageData(ac,:,rrr);
        stdevPrelim(rrr,:) = FateSpecificStdevData(ac,:,rrr);
        
    end
    
    % for x data get rid of the first column which is a zero (padding to
    % fill the matrix)
    xPrelim = LabelCleanStitchedTrajs(1,2:size(LabelCleanStitchedTrajs,2),1);
    
    % find the plot settings for this fate
    FindColor = FateColorSet(ac,:);
    FindLine = FateLineStyleSet(ac);
    FindMarker = FateMarkerSet(ac);      
        
    % find the first and last nonzero elements in the average track data (the start
    % and end of the track)
    [~,StartTraj] = find(yPrelim(1,:),1,'first');
    [~,EndTraj] = find(yPrelim(1,:),1,'last');
    
    xFinal = xPrelim(StartTraj:EndTraj);
    
    yFinal(:,:) = yPrelim(:,StartTraj:EndTraj);
    stdevFinal(:,:) = stdevPrelim(:,StartTraj:EndTraj);
    
    for sss = 1:NoOfSignals
         
        % plot the average traj for each signal for this fate in its own
        % figure (one figure per signal), no stdev bars here
        set(0,'CurrentFigure',Fig_FateSpecAveTrajs(sss));
        % assign each of the trajectory plots colored by fate to its own handle
        FateSpecAveTrajs(ac,sss) = plot(xFinal,yFinal(sss,:));
        
         if strcmp(FindLine,'-') == 1
        
            set(FateSpecAveTrajs(ac,sss),'LineStyle','-');
            set(FateSpecAveTrajs(ac,sss),'Color',FindColor);
            set(FateSpecAveTrajs(ac,sss),'LineWidth',1.8);
            set(FateSpecAveTrajs(ac,sss),'Visible','on');
             
        elseif strcmp(FindMarker,'.') == 1
        
            set(FateSpecAveTrajs(ac,sss),'LineStyle','none');
            set(FateSpecAveTrajs(ac,sss),'Marker','.');
            set(FateSpecAveTrajs(ac,sss),'MarkerEdgeColor',FindColor);
            set(FateSpecAveTrajs(ac,sss),'MarkerFaceColor',FindColor);
            set(FateSpecAveTrajs(ac,sss),'MarkerSize',8);
            set(FateSpecAveTrajs(ac,sss),'Visible','off'); 
            
        end
    
    hold on
    
        % plot the average traj for each signal for this fate in its own
        % figure (one figure per signal), stdev bars added here
        set(0,'CurrentFigure',Fig_FateSpecAveTrajs_Stdev(sss));    
        FateSpecAveTrajs_Stdev(ac,sss) = errorbar(xFinal,yFinal(sss,:),stdevFinal(sss,:));
    
    if strcmp(FindLine,'-') == 1
               
        set(FateSpecAveTrajs_Stdev(ac,sss),'LineStyle','-');
        set(FateSpecAveTrajs_Stdev(ac,sss),'Color',FindColor);
        set(FateSpecAveTrajs_Stdev(ac,sss),'LineWidth',1.8);
        set(FateSpecAveTrajs_Stdev(ac,sss),'Visible','on');
        
    elseif strcmp(FindMarker,'.') == 1
        
        set(FateSpecAveTrajs_Stdev(ac,sss),'LineStyle','none');
        set(FateSpecAveTrajs_Stdev(ac,sss),'Marker','.');
        set(FateSpecAveTrajs_Stdev(ac,sss),'MarkerEdgeColor',FindColor);
        set(FateSpecAveTrajs_Stdev(ac,sss),'MarkerFaceColor',FindColor);
        set(FateSpecAveTrajs_Stdev(ac,sss),'MarkerSize',8);
        set(FateSpecAveTrajs_Stdev(ac,sss),'Visible','off');
        
    end
    
    hold on
    
    end
        
end

for vvv = 1:NoOfSignals
    
    FileName1(vvv) = strcat('Plots/',Signals(vvv),'_FateSpecificAveTrajs.eps');
    saveas(Fig_FateSpecAveTrajs(vvv), FileName1{vvv},'epsc');
    
    FileName2(vvv) = strcat('Plots/',Signals(vvv),'_FateSpecificAveTrajs_Stdev.eps');
    saveas(Fig_FateSpecAveTrajs_Stdev(vvv), FileName2{vvv},'epsc');
    
end







    

%----------------------------------------------------------------------------
% Plot only 'solid' fate trajectories, color corresponds to assigned fate
%----------------------------------------------------------------------------

for ttt = 1:NoOfSignals
    
    FigTitle3(ttt) = strcat('**',Signals(ttt),'** Cell Intensity Trajectories - Colored by Fate, Solid Only');
    
    Fig_TrajsColorByFateSolidOnly(ttt) = figure('Name',FigTitle3{ttt},'NumberTitle','off');
    
end

for aa = 1:size(CleanStitchedTrajs,1)
    
    xPrelim = [];
    yPrelim = [];
    xFinal = [];
    yFinal = [];
    
    % work with the intensity trajectory data for one cell at a time
    for rrr = 1:NoOfSignals
    % for y data get rid of the first column which is the gofigure track id
    yPrelim(rrr,:) = CleanStitchedTrajs(aa,2:size(CleanStitchedTrajs,2),rrr);
    end
    % for x data get rid of the first column which is a zero (padding to
    % fill the matrix)
    xPrelim = LabelCleanStitchedTrajs(1,2:size(LabelCleanStitchedTrajs,2),1);
    
    % get the string that specifies the fate of the current intensity
    % trajectory to be plotted
    CurrentManualFate = CleanFates(aa);
    
    % compare the fate string for the current intensity  trajectory to be
    % plotted with the possible fate strings contained in FateSet, when you
    % find the match in FateSet, use it's index to assign the color that
    % should be used for that fate from FateColorSet 
    for ac = 1:size(FateSet,2)
        FindFate = strcmp(CurrentManualFate,FateSet(ac));
        if FindFate == 1
            FindColor = FateColorSet(ac,:);
            FindLine = FateLineStyleSet(ac);
            FindMarker = FateMarkerSet(ac);
            break
        end
    end
    
    % find the first and last nonzero elements in the track data (the start
    % and end of the track)
    [~,StartTraj] = find(yPrelim,1,'first');
    [~,EndTraj] = find(yPrelim,1,'last');
    
    
    xFinal = xPrelim(StartTraj:EndTraj);
    
    
    for sss = 1:NoOfSignals
        
        yFinal(sss,:) = yPrelim(sss,StartTraj:EndTraj);
    
        set(0,'CurrentFigure',Fig_TrajsColorByFateSolidOnly(sss));
        
    % assign each of the trajectory plots colored by fate to its own handle
    TrajsColorByFate(aa,sss) = plot(xFinal,yFinal(sss,:));
        
    if strcmp(FindLine,'-') == 1
        
        set(TrajsColorByFate(aa,sss),'LineStyle','-');
        set(TrajsColorByFate(aa,sss),'Color',FindColor);
        set(TrajsColorByFate(aa,sss),'LineWidth',1.8);
        set(TrajsColorByFate(aa,sss),'Visible','on');
        
    elseif strcmp(FindMarker,'.') == 1
        
        set(TrajsColorByFate(aa,sss),'LineStyle','none');
        set(TrajsColorByFate(aa,sss),'Marker','.');
        set(TrajsColorByFate(aa,sss),'MarkerEdgeColor',FindColor);
        set(TrajsColorByFate(aa,sss),'MarkerFaceColor',FindColor);
        set(TrajsColorByFate(aa,sss),'MarkerSize',8);
        set(TrajsColorByFate(aa,sss),'Visible','off');
        
    end
    
    hold on
    
    end
        
end

for vvv = 1:NoOfSignals
    
    FileName(vvv) = strcat('Plots/',Signals(vvv),'_SolidTrajsColorByFate.eps');
    saveas(Fig_TrajsColorByFateSolidOnly(vvv), FileName{vvv},'epsc');
    
end

%----------------------------------------------------------------------------
% Plot only 'subjective' fate trajectories, color corresponds to assigned fate
%----------------------------------------------------------------------------

for uuu = 1:NoOfSignals
    
    FigTitle4(uuu) = strcat('**',Signals(uuu),'** Cell Intensity Trajectories - Colored by Fate, Subjective Only');
    
    Fig_TrajsColorByFateSubjectiveOnly(uuu) = figure('Name',FigTitle4{uuu},'NumberTitle','off');
    
end

for aa = 1:size(CleanStitchedTrajs,1)
    
    xPrelim = [];
    yPrelim = [];
    xFinal = [];
    yFinal = [];
    
    % work with the intensity trajectory data for one cell at a time
    for rrr = 1:NoOfSignals
    % for y data get rid of the first column which is the gofigure track id
    yPrelim(rrr,:) = CleanStitchedTrajs(aa,2:size(CleanStitchedTrajs,2),rrr);
    end
    % for x data get rid of the first column which is a zero (padding to
    % fill the matrix)
    xPrelim = LabelCleanStitchedTrajs(1,2:size(LabelCleanStitchedTrajs,2),1);
    
    % get the string that specifies the fate of the current intensity
    % trajectory to be plotted
    CurrentManualFate = CleanFates(aa);
    
    % compare the fate string for the current intensity  trajectory to be
    % plotted with the possible fate strings contained in FateSet, when you
    % find the match in FateSet, use it's index to assign the color that
    % should be used for that fate from FateColorSet 
    for ac = 1:size(FateSet,2)
        FindFate = strcmp(CurrentManualFate,FateSet(ac));
        if FindFate == 1
            FindColor = FateColorSet(ac,:);
            FindLine = FateLineStyleSet(ac);
            FindMarker = FateMarkerSet(ac);
            break
        end
    end
    
    % find the first and last nonzero elements in the track data (the start
    % and end of the track)
    [~,StartTraj] = find(yPrelim,1,'first');
    [~,EndTraj] = find(yPrelim,1,'last');
    
    
    xFinal = xPrelim(StartTraj:EndTraj);
    
    
    for sss = 1:NoOfSignals
        
        yFinal(sss,:) = yPrelim(sss,StartTraj:EndTraj);
    
        set(0,'CurrentFigure',Fig_TrajsColorByFateSubjectiveOnly(sss));
        
    % assign each of the trajectory plots colored by fate to its own handle
    TrajsColorByFate(aa,sss) = plot(xFinal,yFinal(sss,:));
        
    if strcmp(FindLine,'-') == 1
        
        set(TrajsColorByFate(aa,sss),'LineStyle','-');
        set(TrajsColorByFate(aa,sss),'Color',FindColor);
        set(TrajsColorByFate(aa,sss),'LineWidth',1.8);
        set(TrajsColorByFate(aa,sss),'Visible','off');
        
    elseif strcmp(FindMarker,'.') == 1
        
        set(TrajsColorByFate(aa,sss),'LineStyle','-');
        set(TrajsColorByFate(aa,sss),'Color',FindColor);
        set(TrajsColorByFate(aa,sss),'LineWidth',1.8);
        %set(TrajsColorByFate(aa,sss),'Marker','.');
        %set(TrajsColorByFate(aa,sss),'MarkerEdgeColor',FindColor);
        %set(TrajsColorByFate(aa,sss),'MarkerFaceColor',FindColor);
        %set(TrajsColorByFate(aa,sss),'MarkerSize',8);
        set(TrajsColorByFate(aa,sss),'Visible','on');
        
    end
    
    hold on
    
    end
        
end

for vvv = 1:NoOfSignals
    
    FileName(vvv) = strcat('Plots/',Signals(vvv),'_SubjectiveTrajsColorByFate.eps');
    saveas(Fig_TrajsColorByFateSubjectiveOnly(vvv), FileName{vvv},'epsc');
    
end

%----------------------------------------------------------------------------
% Plot all trajectories - smoothed, color corresponds to assigned fate, 'solid' fates are plotted as lines, 'subjective' fates are plotted as filled circles
%----------------------------------------------------------------------------
qqq = 1;

for qqq = 1:NoOfSignals
    
    FigTitle5(qqq) = strcat('**',Signals(qqq),'** Cell Intensity Trajectories - Smoothed, Colored by Fate');
    
    Fig_SmoothTrajsColorByFate(qqq) = figure('Name',FigTitle5{qqq},'NumberTitle','off');
    
end


for aa = 1:size(CleanStitchedTrajs,1)
    
    xPrelim = [];
    yPrelim = [];
    xFinal = [];
    yFinal = [];
    ySmooth = [];
    
    % work with the intensity trajectory data for one cell at a time
    for rrr = 1:NoOfSignals
    % for y data get rid of the first column which is the gofigure track id
    yPrelim(rrr,:) = CleanStitchedTrajs(aa,2:size(CleanStitchedTrajs,2),rrr);
    end
    % for x data get rid of the first column which is a zero (padding to
    % fill the matrix)
    xPrelim = LabelCleanStitchedTrajs(1,2:size(LabelCleanStitchedTrajs,2),1);
    
    % get the string that specifies the fate of the current intensity
    % trajectory to be plotted
    CurrentManualFate = CleanFates(aa);
    
    % compare the fate string for the current intensity  trajectory to be
    % plotted with the possible fate strings contained in FateSet, when you
    % find the match in FateSet, use it's index to assign the color that
    % should be used for that fate from FateColorSet 
    for ac = 1:size(FateSet,2)
        FindFate = strcmp(CurrentManualFate,FateSet(ac));
        if FindFate == 1
            FindColor = FateColorSet(ac,:);
            FindLine = FateLineStyleSet(ac);
            FindMarker = FateMarkerSet(ac);
            break
        end
    end
    
    % find the first and last nonzero elements in the track data (the start
    % and end of the track)
    [~,StartTraj] = find(yPrelim,1,'first');
    [~,EndTraj] = find(yPrelim,1,'last');
    
    
    xFinal = xPrelim(StartTraj:EndTraj);
    
    
    for sss = 1:NoOfSignals
        
        yFinal(sss,:) = yPrelim(sss,StartTraj:EndTraj);
        [ySmooth,~] = moving_average(yFinal(sss,:),2,2);
        
        set(0,'CurrentFigure',Fig_SmoothTrajsColorByFate(sss));
        
    % assign each of the trajectory plots colored by fate to its own handle
    TrajsColorByFate(aa,sss) = plot(xFinal,ySmooth);
        
    if strcmp(FindLine,'-') == 1
        
        set(TrajsColorByFate(aa,sss),'LineStyle','-');
        set(TrajsColorByFate(aa,sss),'Color',FindColor);
        set(TrajsColorByFate(aa,sss),'LineWidth',1.8);
        set(TrajsColorByFate(aa,sss),'Visible','on');
        
    elseif strcmp(FindMarker,'.') == 1
        
        set(TrajsColorByFate(aa,sss),'LineStyle','none');
        set(TrajsColorByFate(aa,sss),'Marker','.');
        set(TrajsColorByFate(aa,sss),'MarkerEdgeColor',FindColor);
        set(TrajsColorByFate(aa,sss),'MarkerFaceColor',FindColor);
        set(TrajsColorByFate(aa,sss),'MarkerSize',8);
        set(TrajsColorByFate(aa,sss),'Visible','on');
        
    end
    
    hold on
    
    end
        
end

for vvv = 1:NoOfSignals
    
    FileName(vvv) = strcat('Plots/',Signals(vvv),'_Smoothed_AllTrajsColorByFate.eps');
    saveas(Fig_SmoothTrajsColorByFate(vvv), FileName{vvv},'epsc');
    
end

%----------------------------------------------------------------------------
% Plot first derivative of all trajectories after smoothing - color corresponds to assigned fate, 'solid' fates are plotted as lines, 'subjective' fates are plotted as filled circles
%----------------------------------------------------------------------------
qqq = 1;

for qqq = 1:NoOfSignals
    
    FigTitle6(qqq) = strcat('**',Signals(qqq),'** First Derivative of Smoothed Cell Intensity Trajectories - Colored by Fate');
    
    Fig_DerivativeSmoothTrajsColorByFate(qqq) = figure('Name',FigTitle6{qqq},'NumberTitle','off');
    
end


for aa = 1:size(CleanStitchedTrajs,1)
    
    xPrelim = [];
    yPrelim = [];
    xFinal = [];
    yFinal = [];
    ySmooth = [];
    
    % work with the intensity trajectory data for one cell at a time
    for rrr = 1:NoOfSignals
    % for y data get rid of the first column which is the gofigure track id
    yPrelim(rrr,:) = CleanStitchedTrajs(aa,2:size(CleanStitchedTrajs,2),rrr);
    end
    % for x data get rid of the first column which is a zero (padding to
    % fill the matrix)
    xPrelim = LabelCleanStitchedTrajs(1,2:size(LabelCleanStitchedTrajs,2),1);
    
    % get the string that specifies the fate of the current intensity
    % trajectory to be plotted
    CurrentManualFate = CleanFates(aa);
    
    % compare the fate string for the current intensity  trajectory to be
    % plotted with the possible fate strings contained in FateSet, when you
    % find the match in FateSet, use it's index to assign the color that
    % should be used for that fate from FateColorSet 
    for ac = 1:size(FateSet,2)
        FindFate = strcmp(CurrentManualFate,FateSet(ac));
        if FindFate == 1
            FindColor = FateColorSet(ac,:);
            FindLine = FateLineStyleSet(ac);
            FindMarker = FateMarkerSet(ac);
            break
        end
    end
    
    % find the first and last nonzero elements in the track data (the start
    % and end of the track)
    [~,StartTraj] = find(yPrelim,1,'first');
    [~,EndTraj] = find(yPrelim,1,'last');
    
    xFinal1 = xPrelim(StartTraj:EndTraj);
    
    % specify the window over which derivative will be calculated by
    % dwindow, dwindow is the number of time steps over which you want to take the
    % derivative
    dwindow = 2;
        
    xFinal = xPrelim(StartTraj+dwindow:EndTraj);
    
    time_interval = xFinal1(2)-xFinal1(1);
    dwindowtime = dwindow*time_interval;  
    
    
    for sss = 1:NoOfSignals
        
        yFinal(sss,:) = yPrelim(sss,StartTraj:EndTraj);
        [ySmooth,~] = moving_average(yFinal(sss,:),2,2);
        
        dy = zeros(1,size(ySmooth,2)-dwindow);
        
        for a = 1:size(dy,2)
            dy(a) = (ySmooth(a+dwindow) - ySmooth(a))/dwindowtime;
        end
        
        set(0,'CurrentFigure',Fig_DerivativeSmoothTrajsColorByFate(sss));
        
    % assign each of the trajectory plots colored by fate to its own handle
    TrajsColorByFate(aa,sss) = plot(xFinal,dy);
        
    if strcmp(FindLine,'-') == 1
        
        set(TrajsColorByFate(aa,sss),'LineStyle','-');
        set(TrajsColorByFate(aa,sss),'Color',FindColor);
        set(TrajsColorByFate(aa,sss),'LineWidth',1.8);
        set(TrajsColorByFate(aa,sss),'Visible','on');
        
    elseif strcmp(FindMarker,'.') == 1
        
        set(TrajsColorByFate(aa,sss),'LineStyle','none');
        set(TrajsColorByFate(aa,sss),'Marker','.');
        set(TrajsColorByFate(aa,sss),'MarkerEdgeColor',FindColor);
        set(TrajsColorByFate(aa,sss),'MarkerFaceColor',FindColor);
        set(TrajsColorByFate(aa,sss),'MarkerSize',8);
        set(TrajsColorByFate(aa,sss),'Visible','on');
        
    end
    
    hold on
    
    end
        
end

for vvv = 1:NoOfSignals
    
    FileName(vvv) = strcat('Plots/',Signals(vvv),'_DerivativeOfSmoothed_AllTrajsColorByFate.eps');
    saveas(Fig_DerivativeSmoothTrajsColorByFate(vvv), FileName{vvv},'epsc');
    
end
