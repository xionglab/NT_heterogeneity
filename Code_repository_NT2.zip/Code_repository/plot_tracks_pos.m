
% this function plots individual tracks by fate on the same plot
function []=plot_tracks_pos(InputTrackMatrix,InputTimeVector,CleanFates,FatesToPlot,col)

% title
ftitle='Single Tracks';
% x label
fxlabel='Time (hpf)';
% y label
fylabel='Distance (\mum)';

% ------specify x and y ranges------
xrange=[min(InputTimeVector) max(InputTimeVector)];
yrange=[min(0,min(min(InputTrackMatrix(:,2:end,1)))) max(max(InputTrackMatrix(:,2:end,1)))];

% Create figure
figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1,...
    'Position',[0.13 0.11 0.658433382137628 0.810792079207921]);

for i=1:size(FatesToPlot,2)
   M=InputTrackMatrix(strcmp(CleanFates,FatesToPlot(i)),:,1);
   for j=1:size(M,1)
       V=M(j,2:end);
       V(V==0)=NaN;
       plot(InputTimeVector,V,'LineWidth',2,'Color',col(i,:));
       hold on;
   end
end

% set axis format and ranges
xlim(axes1,xrange);
ylim(axes1,yrange);
set(gca,'YAxisLocation','left');
set(gca,'box','off');
set(gca,'FontSize',12,'LineWidth',2);

% Create title
title(ftitle,'FontSize',20);

% Create xlabel
xlabel(fxlabel,'FontSize',14);

% Create ylabel
ylabel(fylabel,'FontSize',14);

end