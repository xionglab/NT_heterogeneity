


function M=AveVal_1(StandardTrackMatrix)
% this function grabs the average value from a set of tracks and return a
% matrix M

% inputs: 1. StandardTrackMatrix - tracks starting with a track ID, followed by the values.

% outputs: M is a matrix of the same dimensions and rows as the input
% matrix, it only has two columns, row one is the trackIDs as the input,
% column two is average value across the track, ignoring zero values


dim=size(StandardTrackMatrix,3);
row=size(StandardTrackMatrix,1);
M=StandardTrackMatrix;
M(:,3:end,:)=[];

for sss=1:dim
    for i=1:row
    vals = []; % clear the array each time
    vals = StandardTrackMatrix(i,2:end,sss); % assign all track vals for the current track into array
    M(i,2,sss)=mean(vals(vals~=0)); % calc ave val ignoring zero vals
    end
end
end