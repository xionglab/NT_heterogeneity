
function []=plot_times_3(PP,ThRanges,CleanFates,FatesToPlot,col,whichsignal)

% This script plots the time counter results by fate - updated to deal with
% intervals
% using tony's error bar scatter
% needs CleanFates from the standard workspace and output of TimeCounter 

InputMatrix=PP;

% Run TimeCounter to get the count matrix N
for i=1:length(ThRanges)-1
N=TimeCounter_1(InputMatrix,ThRanges(i))-TimeCounter_1(InputMatrix,ThRanges(i+1));

% Create figure
figure1 = figure;
% Create axes
axes1 = axes('Parent',figure1);
xlim(axes1,[0.5 4.5]);
% ylim(axes1,[0 40]);
box(axes1,'on');
hold(axes1,'all');
title(axes1,[num2str(ThRanges(i)),'<Signal ',num2str(whichsignal),'<',num2str(ThRanges(i+1))]);

% the cell array to store input for tony script
tony=FatesToPlot;
for j=1:size(FatesToPlot,2)
    index=strcmp(CleanFates,FatesToPlot(j));
    M=N(index,:,whichsignal);
    tony{j}=M(:,2);
end

mycolorscatterplot1d(tony,col,1);

% Create xlabel
xlabel('Cell Types');
% Create ylabel
ylabel('Number of Time points');

end
end
