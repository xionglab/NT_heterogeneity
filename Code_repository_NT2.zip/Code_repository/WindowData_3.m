
function [M0,M0TimeAxis]=WindowData_3(InputMatrix,TimePointArrayHPF,StartWindow,EndWindow)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Inputs - User Changeable %%%%%%%%%
% InputMatrix: input matrix holding trajectories to be windowed 
% TimePointArrayHPF: corresponding input time axis in hpf
% StartWindow: starting time of data window in hpf
% EndWindow: ending time of data window in hpf
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%% Output  %%%%%%%%%%%%%%%%%%%%%%%%%%
% output is a data matrix with exactly the same structure as that input,
% and corresponding windowed time axis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

StartLog = TimePointArrayHPF >= StartWindow;
StartInd = find(StartLog, 1, 'first');

EndLog = TimePointArrayHPF >= EndWindow; 
EndInd = find(EndLog, 1, 'first');

M0TimeAxis = TimePointArrayHPF(StartInd:EndInd);
M0 = cat(2,InputMatrix(:,1,:),InputMatrix(:,StartInd+1:EndInd+1,:));
end