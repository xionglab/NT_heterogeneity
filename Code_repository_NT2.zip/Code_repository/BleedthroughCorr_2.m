
% this function aims to involve more inteligence in bleedthrough correction
% Plot the two channels against each other to determine the ratio of
% correction

function Corr_CleanStitchedTrajs=BleedthroughCorr_2(CleanStitchedTrajs)

% Inputs: CleanStitchedTrajs from the standard work space

% the idea is to find r1 and r2 by looking for the areas in an imaginary
% double plot (in which chanels 1 and 2 are plotted against each other)
% where no data points can be found.

% To realize the idea - first plot all values between two channels
row=size(CleanStitchedTrajs,1);
col=size(CleanStitchedTrajs,2)-1;
signal1=reshape(CleanStitchedTrajs(:,2:end,1),[1,row*col]);
signal2=reshape(CleanStitchedTrajs(:,2:end,2),[1,row*col]);
% plot(signal1,signal2);
% the lines y=r1*x and x=r2*y will be used to identify the bleedthrough
% ratios
a=0.001:0.001:0.5;
% possible range of bleedthrough ratios
j1=zeros(1,length(a));j2=zeros(1,length(a));
for i=1:length(a)
j1(i)=min(signal2-a(i).*signal1)>=0; j2(i)=min(signal1-a(i).*signal2)>=0;
% here the lines y-r1*x=0 and x-r2*y=0 are tested against all the data
% points in the matrix, the minimal value from each test will be negative
% if there is one data point outside the line, this generates a logical 0
% in j. Therefore, the boundary point where logical 1 becomes 0 indicates
% the fit line ratios r1 and r2.
end

% signal2 is y, r1 multiplies x, which is signal1 and so on.
r1=a(max(sum(j1),1));
r2=a(max(sum(j2),1));

Corr_CleanStitchedTrajs=CleanStitchedTrajs;
Corr_CleanStitchedTrajs(:,2:end,1)=Corr_CleanStitchedTrajs(:,2:end,1)-r2.*CleanStitchedTrajs(:,2:end,2);
Corr_CleanStitchedTrajs(:,2:end,2)=Corr_CleanStitchedTrajs(:,2:end,2)-r1.*CleanStitchedTrajs(:,2:end,1);

% force zeros
Corr_CleanStitchedTrajs(Corr_CleanStitchedTrajs<0)=0;