% this function normalizes the filtered data to specified maximum value in
% each dimension therefore making it easier for downstream plotting

function M=NormalizeData_1(InputMatrix,Scaleto)

M=InputMatrix;
dim=size(InputMatrix,3);

for i=1:dim
    M(:,2:end,i)=InputMatrix(:,2:end,i)./max(max(InputMatrix(:,2:end,i))).*Scaleto;
end

end
