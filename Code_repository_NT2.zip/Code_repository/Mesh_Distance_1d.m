
function MeshDis = Mesh_Distance_1d(X,TimeAxis,T)
% this function calculates the distances between every other cell at a
% certain time point, for a given set of inputmatrix (X,Y,Z), the output is
% in the standard matrix format, a diagnal 0 would make the bottom right half of
% the matrix zeros.

row=size(X,1);
MeshDis=zeros(row,row+1);
MeshDis(:,1)=X(:,1);
ind=TimeAxis==T;
x=X(:,2:end);
xt=x(:,ind);
xt(xt==0)=NaN;

for i=1:row
    for j=i:row
        MeshDis(i,j+1)=sqrt((xt(i)-xt(j))^2);
    end
end

end
