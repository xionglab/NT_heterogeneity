function DoubleSignalPlot_2(xArraywithPad,Signal1Matrix,Signal2Matrix)

xArray = xArraywithPad(2:size(xArraywithPad,2));

Signal1 = Signal1Matrix(:,2:size(Signal1Matrix,2));
Signal2 = Signal2Matrix(:,2:size(Signal2Matrix,2));

gofigid = Signal1Matrix(:,1);

maxSignal1 = max(max(Signal1));
maxSignal2 = max(max(Signal2));
minTime = min(xArray);
maxTime = max(xArray);

NoOfPlots = size(Signal1,1);

for a = 1:NoOfPlots

currentgofigid = gofigid(a);
currenttitle = num2str(currentgofigid);

currentSig1 = Signal1(a,:);
currentSig2 = Signal2(a,:);

startInd = find(currentSig1, 1, 'first');
endInd = find(currentSig1, 1, 'last');

currentfig = figure(a);

[ax,h1,h2]=plotyy(xArray(startInd:endInd),currentSig1(startInd:endInd),xArray(startInd:endInd),currentSig2(startInd:endInd));
title(currenttitle);

set(ax(1),'ylim',[0 maxSignal1])
set(ax(2),'ylim',[0 maxSignal2])
set(ax(1),'xlim',[minTime maxTime])
set(ax(2),'xlim',[minTime maxTime])

set(h1,'color',[1 0 0])
set(h2,'color',[0 1 0])

set(h1,'LineWidth',10)
set(h2,'LineWidth',10)

end