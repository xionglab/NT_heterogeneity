function Deriv1Data = Deriv1Data_8(InputData,InputDataTime,dWindow)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Inputs %%%%%%%%%
% InputData - data matrix holding trajectories to be smoothed  -  % assumes the first column of this is gofigure track id, that the time array is held separately (e.g. there are as many rows as gofigure track ids), when there is no data for tracks data is padded with zeros
% DataTimeArray - row vector of timepoints corresponding to the data in InputData
% dWindow - number of time steps over which you want to take the first derivative
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%% Output  %%%%%%%%%%%%%%%%%%%%%%%%%%
% Deriv1Data - a matrix of the same size and structure as InputData,
% derivative is calculated using a reverse window; this means that the
% derivative cannot be calculated for the first dWindow timepoints, and
% the data values for these timepoints are set to zero
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Deriv1Data = InputData; % initialize a new data matrix with the same format as original data, this will hold the first deriv data


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xPrelim = InputDataTime;

time_interval = xPrelim(2)-xPrelim(1);
dWindowTime = dWindow*time_interval;

for rrr = 1:size(InputData,3)

for aa = 1:size(InputData,1)
    
    yPrelim = [];
    
    yFinal = [];
    
    yDeriv1 = [];
    
    
    % work with the intensity trajectory data for one gofigure id at a time
   
    % for y data get rid of the first column which is the gofigure track id
    % yPrelim has as many rows as NoOfSignals and as many columns as number
    % of timepoints in dataset
    yPrelim = InputData(aa,2:end,rrr);
    
    % find the first and last nonzero elements in the trajectory data (the start
    % and end of the trajectory)
    StartTraj = find(yPrelim,1,'first');
    EndTraj = find(yPrelim,1,'last');
    
    yFinal = yPrelim(StartTraj:EndTraj);
   
    % derivative is calculated over a reverse window so final derivative data for each trajectory will 
    % have 'dWindow' fewer timepoints of data on the front end than it has for the raw/smoothed data 
    yDeriv1 = zeros(1,size(yFinal,2)-dWindow); % initialize a vector of zeros of the correct length
    
    for a = 1:size(yDeriv1,2)
        
            yDeriv1(a) = (yFinal(a+dWindow) - yFinal(a))/dWindowTime;
    end
    
    Deriv1Data(aa,StartTraj+1:StartTraj+dWindow,rrr) = 0; % derivative is calculated over a reverse window so final derivative data for each trajectory will have 'dWindow' fewer timepoints of data on the front end than it has for the raw/smoothed data - replace that raw/smoothed data with zeros  
    Deriv1Data(aa,StartTraj+1+dWindow:EndTraj+1,rrr) = yDeriv1;
    
end
        
end

