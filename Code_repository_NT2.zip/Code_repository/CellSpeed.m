
% this function computes the cells' speed of movement, or more precisely,
% the displacement over given time intervals
% the input is the X,Y,Z position matrixes, an average track is first
% computed for the dataset, then distances to that average track for each
% time point is computed to remove global shiftings

% the output is a standard matrix including trackIDs in the first column,
% and additional columns match that of TimePointArrayHPF, each element is a
% speed calculation over that time period, specified by user input time
% intervals (as number of time points)

function N = CellSpeed(X,Y,Z,TimePointArrayHPF,interval)

aveX = zeros(1,size(TimePointArrayHPF,2));
aveY = zeros(1,size(TimePointArrayHPF,2));
aveZ = zeros(1,size(TimePointArrayHPF,2));
D=X;
X(X==0)=NaN;
Y(Y==0)=NaN;
Z(Z==0)=NaN;

for i=1:size(TimePointArrayHPF,2)
    aveX(i)=mean(X(~isnan(X(:,i+1)),i+1));
    aveY(i)=mean(Y(~isnan(Y(:,i+1)),i+1));
    aveZ(i)=mean(Z(~isnan(Z(:,i+1)),i+1));
    for j=1:size(D,1)
        D(j,i+1)=sqrt((X(j,i+1)-aveX(i))^2+(Y(j,i+1)-aveY(i))^2+(Z(j,i+1)-aveZ(i))^2);
    end
end

N=D;
for k=1:size(N,2)-1-interval
    N(:,k+1)=abs((N(:,k+1+interval)-N(:,k+1)))./interval;
end
N(:,size(N,2)-interval:size(N,2))=[];
N(isnan(N))=0;

end