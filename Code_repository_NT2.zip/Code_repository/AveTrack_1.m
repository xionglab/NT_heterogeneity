
function aveT=AveTrack_1(CleanStitchedTrajs,trackID)
% This function calculates the average track from a list of tracks
% Input: The standard Trajs matrix and A list of trackIDs (GoFigureIDs) to average
% Output: In the first row a sinlge track using the same data structure, 
% but the first element will be 0 for future re-assignments
% In the second row a single "track" but containing standard deviation

dim=size(CleanStitchedTrajs,3);
col=size(CleanStitchedTrajs,2);

aveT=CleanStitchedTrajs(1:2,:,:);

ind=ismember(CleanStitchedTrajs(:,1,1),trackID);
M=CleanStitchedTrajs(ind,:,:);

for sss=1:dim
    for i=1:col-1
        V=M(:,i+1,sss);
        aveT(1,i+1,sss)=mean(V(V~=0));
        aveT(2,i+1,sss)=std(V(V~=0));
    end
end
aveT(1:2,1,:)=0;


end