function PlotTrajs4(TimesArrayHPF,yMatrixWtrackID,xLabel,yLabel,plotTitle,SpecAxis,RGBColor,HoldFig)

% example calls for plotting MN Ptc trajectories and MN LMDV dist
% trajectories respectively:
%
% PlotTrajs4(LabelCleanStitchedTrajs(1,:,1),CleanStitchedTrajs_Fate_MN(:,:,1),'Time(hpf)','Ptc Intensity','MN - Ptc vs. Time',[],[0 0 204],0)
% PlotTrajs4(NotocordTimesArrayHPF,Clean_LMDV_StitchedTrajs_Fate_MN,'Time(hpf)','LMDV Distance (um)','MN - LMDV Distance vs. Time',[],[0 0 204],1)

% TimesArrayHPF is an array holding the x values

% yMatrixWtrackID is a matrix with time dependent trajectory data per track
% in each row, the gofigure id of each track is in the first column

% xLabel, yLabel and plotTitle should all be strings

% SpecAxis is a 4 element array that specifies x min/max and y min/max (e.g. [xmin xmax ymin ymax]), if left empty (e.g. []) the default is to auto scale to best fit the data 

% RGBColor as a 3 element array that specifies the RGB color you want the plotted lines to be (e.g.
% [0 0 255]

% HoldFig is either 0 or 1; 0 = plot in a new figure, 1 = plot in already
% open figure

MRGBColor = RGBColor ./ 255; % Matlab scales the RGB code to be between 0 and 1 for each element

if HoldFig == 1
    hold on
elseif HoldFig == 0 
% initialize a new figure window
figure
end

for aa = 1:size(yMatrixWtrackID,1)
    
    xPrelim = [];
    yPrelim = [];
    xFinal = [];
    yFinal = [];
    
    % work with the trajectory data for one cell at a time
    % for y data get rid of the first column which is the gofigure track id
    yPrelim = yMatrixWtrackID(aa,2:size(yMatrixWtrackID,2));
    
    % for x data get rid of the first column which is a zero (padding to
    % fill the matrix)
    xPrelim = TimesArrayHPF;
      
    % find the first and last nonzero elements in the track data (the start
    % and end of the track)
    [~,StartTraj] = find(yPrelim,1,'first');
    [~,EndTraj] = find(yPrelim,1,'last');
    
    xFinal = xPrelim(StartTraj:EndTraj);
    yFinal = yPrelim(StartTraj:EndTraj);    
     
    Traj(aa) = plot(xFinal,yFinal);  
        
    set(Traj(aa),'LineStyle','-');
    set(Traj(aa),'Color',MRGBColor);
    set(Traj(aa),'LineWidth',1.8);
    set(Traj(aa),'Visible','on');
    
    hold on
    
end
  
GoFigIds = yMatrixWtrackID(:,1);
StringGoFigIds = num2str(GoFigIds);

% label figure
title(plotTitle,'FontSize',20,'FontWeight','bold')
xlabel(xLabel,'FontSize',16,'FontWeight','bold')
ylabel(yLabel,'FontSize',16,'FontWeight','bold')
Leg = legend(Traj,StringGoFigIds); % this links the trajectories with their gofigure id and creates a legend - the legend is not very useful but you can delete it and then use View>Plot Browser in the Matlab figure, in this view you can click on each line in the plot and see its associated gofigure id, you can also change the color of single lines in the plot to make them stand out

set(Leg,'visible','off');

% if the input parameter SpecAxis specifies [xmin xmax ymin ymax] then use
% those to scale the axis, otherwise autoscale
if length(SpecAxis) == 4
    axis(SpecAxis)
else 
    axis tight
end

    

        
