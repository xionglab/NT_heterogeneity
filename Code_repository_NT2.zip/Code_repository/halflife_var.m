% This script computes test scores using a variety of Kaede mRNA half life
% to test the robustness of conclusions against an important parameter

halflife=[0.1875,0.375,0.75,1.5,3,6,12,24];
score=zeros(length(halflife),4);
score(:,1)=halflife';

% this block use ptc:kaede signal
FatesToTest = {'LFP' 'MN' 'DorsalToMN'};
% specify corresponding colors
colf=[0.87058824300766,0.490196079015732,0;0 1 0;0 0 1];

for i=1:length(halflife)

% Use a transcription model - with known RNA half lives, perform a
% transform, half live has unit of hours
k=log(2)/halflife(i);
PP=M0_d1.*k+M0_d2;
TT=M0TimeAxis;    
    
% response time model
N = TimeCounter_1(PP,0.05);
modelname='Response time ';
data1=Test(N,0,CleanFates,FatesToTest,colf,2,0,modelname);
% max transient model
N = Max_1(PP);
modelname='Max transient ';
data2=Test(N,0,CleanFates,FatesToTest,colf,2,0,modelname);
% average response level model
N = AveVal_1(PP);
modelname='Average response level ';
data3=Test(N,0,CleanFates,FatesToTest,colf,2,0,modelname);

score(i,2:4)=[data1{6},data2{6},data3{6}];
end

