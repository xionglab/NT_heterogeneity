
% this standalone script tests all plots assuming raw data (NewFinalWrkspace) and All_filters
% data have been loaded

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test position models here
% specify fates to test in the model
FatesToTest = {'LFP' 'MN' 'DorsalToMN'};
% specify corresponding colors
colf=[0 0 1;0 1 0;0.87058824300766,0.490196079015732,0];
modelname='LMDV position at ';
Test_Position(CleanFX_LMDVDistTrajs,NotocordTimesArrayHPF,CleanFates,FatesToTest,colf,modelname);
modelname='LM position at ';
Test_Position(abs(CleanFX_LMDistTrajs),NotocordTimesArrayHPF,CleanFates,FatesToTest,colf,modelname);
modelname='DV position at ';
Test_Position(CleanFX_DVDistTrajs,NotocordTimesArrayHPF,CleanFates,FatesToTest,colf,modelname);

%%%%%%%%%%%%%%%%%%%%%
% testing division related model here
%N = DivisionTime(CleanStitchedTrajs,DivIdListMother1st);
%modelname='Division time ';
%Test(N,0,CleanFates,FatesToTest,colf,2,1,modelname);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test intensity models here, MFP will be excluded
% this block use ptc:kaede signal
FatesToTest = {'LFP' 'MN' 'DorsalToMN'};
% specify corresponding colors
colf=[0.87058824300766,0.490196079015732,0;0 1 0;0 0 1];

% response time model
N = TimeCounter_1(PP,0.05);
modelname='Response time ';
Test(N,0,CleanFates,FatesToTest,colf,2,0,modelname);
% max transient model
N = Max_1(PP);
modelname='Max transient ';
Test(N,0,CleanFates,FatesToTest,colf,2,0,modelname);
% average response level model
N = AveVal_1(PP);
modelname='Average response level ';
Test(N,0,CleanFates,FatesToTest,colf,2,0,modelname);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test intensity models here, MFP will be excluded
% this block use olig2:gfp signal, note the order in FatesToTest is changed
FatesToTest = {'MN' 'LFP' 'DorsalToMN'};
% specify corresponding colors
colf=[0 1 0;0.87058824300766,0.490196079015732,0;0 0 1];

% response time model
N = TimeCounter_1(PP,0.05);
modelname='Response time ';
Test2(N,0,CleanFates,FatesToTest,colf,2,0,modelname);
% max transient model
N = Max_1(PP);
modelname='Max transient ';
Test2(N,0,CleanFates,FatesToTest,colf,2,0,modelname);
% average response level model
N = AveVal_1(PP);
modelname='Average response level ';
Test2(N,0,CleanFates,FatesToTest,colf,2,0,modelname);

%%%%%%%%%%%%%%%%%%%%%
% general testing example
modelname='General testing example ';
% the model for this testing example is:
% raw kaede intensity at 12hpf predicts fate
Test(CleanStitchedTrajs,TimePointArrayHPF,CleanFates,FatesToTest,colf,12,1,modelname);
