function SmoothData = SmoothData_6(InputData,Window)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Inputs %%%%%%%%%
% InputData - data matrix holding trajectories to be smoothed  -  % assumes the first column of this is gofigure track id, that the time array is held separately (e.g. there are as many rows as gofigure track ids), when there is no data for tracks data is padded with zeros
% Window - smoothing window half length
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%% Output  %%%%%%%%%%%%%%%%%%%%%%%%%%
% SmoothData - a matrix of the same size and structure as InputData, data is
% smoothed with a simple rectangular smoothing function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


SmoothData = InputData; % initialize a new data matrix with the same format as original data, this will hold the smoothed data

for rrr = 1:size(InputData,3)
    
    for aa = 1:size(InputData,1)
    
    % work with the intensity trajectory data for one gofigure id at a time   
    yPrelim = [];
    yFinal = [];
    ySmooth = [];
    % for y data get rid of the first column which is the gofigure track id
    % yPrelim has as many rows as NoOfSignals and as many columns as number
    % of timepoints in dataset
    yPrelim = InputData(aa,2:end,rrr);
    
    % find the first and last nonzero elements in the trajectory data (the start
    % and end of the trajectory)
    StartTraj = find(yPrelim,1,'first');
    EndTraj = find(yPrelim,1,'last');  
    
    yFinal = yPrelim(StartTraj:EndTraj);
    ySmooth = moving_average(yFinal,Window,2); % third input argument here specifies that data is in rows, if data is in columns set this parameter to 1
    
    SmoothData(aa,StartTraj+1:EndTraj+1,rrr) = ySmooth;
    end
     
end


