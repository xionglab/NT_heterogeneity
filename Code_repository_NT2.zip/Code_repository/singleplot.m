
% Status: Testing
% Use: generate a single plot showing one or many user specified tracks
% Purpose: data interaction / figure making
% Inputs:
%   User specify: trackID ---Array of GoFigure IDs designating the tracks
% to plot // whichSignal ---1=kaede only, 2=gfp only
%   From Standard WorkSpace: TimePointArrayHPF // CleanStitchedTrajs

% Example usage (copy to run): 
% singleplot(CleanStitchedTrajs(:,1,1),1,TimePointArrayHPF,CleanStitchedTrajs);

function []=singleplot(trackID,whichSignal,TimePointArrayHPF,CleanStitchedTrajs)



for i=1:length(trackID)
row=CleanStitchedTrajs(:,1,1)==trackID(i);
plot(TimePointArrayHPF,CleanStitchedTrajs(row,2:end,whichSignal));
hold on;
end

axis([TimePointArrayHPF(1),TimePointArrayHPF(end),0,max(max(CleanStitchedTrajs(:,2:end,whichSignal)))]);
xlabel('Time (hpf)','FontSize',14);
if whichSignal==1
    ylabel('Kaede Intensity (A.U.)','FontSize',14);
elseif whichSignal==2
    ylabel('GFP Intensity (A.U.)','FontSize',14);
end

