
function MeshDis = Mesh_Distance(X,Y,Z,TimeAxis,T)
% this function calculates the distances between every other cell at a
% certain time point, for a given set of inputmatrix (X,Y,Z), the output is
% in the standard matrix format, a diagnal 0 would make the bottom right half of
% the matrix zeros.

row=size(X,1);
MeshDis=zeros(row,row+1);
MeshDis(:,1)=X(:,1);
ind=TimeAxis==T;
x=X(:,2:end);y=Y(:,2:end);z=Z(:,2:end);
xt=x(:,ind);yt=y(:,ind);zt=z(:,ind);
xt(xt==0)=NaN;yt(yt==0)=NaN;zt(zt==0)=NaN;

for i=1:row
    for j=i:row
        MeshDis(i,j+1)=sqrt((xt(i)-xt(j))^2+(yt(i)-yt(j))^2+(zt(i)-zt(j))^2);
    end
end

end
