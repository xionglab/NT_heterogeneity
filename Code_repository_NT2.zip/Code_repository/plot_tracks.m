
% this function plots individual tracks by fate on the same plot
function []=plot_tracks(InputTrackMatrix,InputTimeVector,CleanFates,FatesToPlot,col,whichsignal,plotname)

% title
ftitle=plotname;
% x label
fxlabel='Time (hpf)';
% y label
if whichsignal==1
    fylabel='Tg(ptch2:kaede) Kaede Intensity (A.U.)';
elseif whichsignal==2
    fylabel='GFP Intensity (A.U.)';
end

% ------specify x and y ranges------
xrange=[min(InputTimeVector) max(InputTimeVector)];
yrange=[0 max(max(InputTrackMatrix(:,2:end,whichsignal)))];

% Create figure
figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1,...
    'Position',[0.13 0.11 0.658433382137628 0.810792079207921]);

for i=1:size(FatesToPlot,2)
   M=InputTrackMatrix(strcmp(CleanFates,FatesToPlot(i)),:,:);
   for j=1:size(M,1)
       V=M(j,2:end,whichsignal);
       V(V==0)=NaN;
       plot(InputTimeVector,V,'LineWidth',2,'Color',col(i,:),'DisplayName',...
           [num2str(M(j,1,1)),' ',CleanFates{InputTrackMatrix(:,1,1)==M(j,1,1)}]);
       hold on;
   end
end

% set axis format and ranges
xlim(axes1,xrange);
ylim(axes1,yrange);
set(gca,'YAxisLocation','left');
set(gca,'box','off');
set(gca,'FontSize',12,'LineWidth',2);

% Create title
title(ftitle,'FontSize',20);

% Create xlabel
xlabel(fxlabel,'FontSize',14);

% Create ylabel
ylabel(fylabel,'FontSize',14);

% Create legend



end



