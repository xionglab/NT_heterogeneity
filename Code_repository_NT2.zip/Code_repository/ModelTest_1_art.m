
% this function will test the predictive power of a set of values to cell
% fates, and return a graphic representation of the test result, as well as
% percentage of correct predictions, as well as a score for the model

function datastore=ModelTest_1_art(InputValues,InputFates,FatesToTest,col,modelname)
% 
% Input: 
% InputValues - a set of values that are supposed to predict fates as a grade, in
% the standard format (i.e., having a column of trackIDs)
% InputFates - corresponding actual fates, CleanFates
% FatesToTest - fates to test the model on, cell array
% col - colors of the flag
% modelname - string,  model name
%
% Output: 
% the best possible model illustrated as a flag
% datastore - contains:
% Th - vector of threshold vals
% corrP - vector of percentage of correct predictions for each threshold
% score - vector of 'comprehensive scores' for each threshold

% this section cleans up Fates not tested, e.g. MFP
ind=strcmp(InputFates,FatesToTest{1});
for ss=2:size(FatesToTest,2)
    ind=ind+strcmp(InputFates,FatesToTest{ss});
end
InputValues = InputValues(ind==1,:);
InputFates = InputFates(ind==1);

% output storage
Nth=size(FatesToTest,2)-1; % Nth - number of thresholds to calculate
Th=zeros(1,Nth); % Th - will store threshold vals
% Determine how many thresholds to look for given the number of fates
corrP=zeros(1,Nth);
% store the correct percentage of prediction for each threshold
thscore=zeros(1,Nth);
% best product of the threshold selection, each threshold has a score for
% the model being tested
modelscore=1;
% define a single score for the model here

corrC=zeros(1,length(InputValues(:,2)));
corrR=zeros(1,length(InputValues(:,2)));
% this stores the compound correct prediction rate
% and the ratio of correct predictions

[seq,I]=sort(InputValues(:,2),'descend');
    % in seq, the values are sorted from big to small

% this part below determines the threholds to draw and calculate how well
% the threholds do in predicting fates
for i=1:Nth
    for j=1:length(seq)
    % starting from seq(1) the values will each be tested for best possible
    % threshold
    above=InputFates(InputValues(:,2)>=seq(j));
    % the indices obtained by comparing InputValues with seq(j) are used to
    % get the fates in InputFates, storing in the cell arry "above"
    % here the model assumes values above the threshold will be fate 1 and
    % below will be fate 2 (fate 3 is also below but does not matter for this test)
    below=InputFates(InputValues(:,2)<seq(j));
    totest1=sum(strcmp(InputFates,FatesToTest(i))); % how many cells of fate i are there total
    correct1=sum(strcmp(above,FatesToTest(i))); % how many cells of fate i are predicted to be above the threshold (e.g. predicted correctly) 
    totest2=sum(strcmp(InputFates,FatesToTest(i+1))); % how many cells of fate i+1 are there total
    correct2=sum(strcmp(below,FatesToTest(i+1))); % how many cells of fate i+1 are predicted to be below the threshold (e.g. predicted correctly)
    corrC(j)=((correct1/totest1)^totest1*(correct2/totest2)^totest2)... 
        ^(1/(totest1+totest2));
    % this calculates a compound correct ratio as criteria to select model,
    % this way the bias of disproportional fate groups is minimized
    corrR(j)=(correct1+correct2)/(totest1+totest2);
    % this sums up the number of correct predictions for each (j)
    end
    
    Th(i)=max(seq(corrC==max(corrC)));  % set the threshold value at the one which achieves the highest comprehensive score for predicting the two fates involved in that threshold
    corrP(i)=max(corrR(corrC==max(corrC))); % store the % of cells of the two fates involved in this threshold that are correctly predicted by this threshold 
    thscore(i)=max(corrC); % store the threshold's comprehensive score for predicting the two fates involved in this threshold 
    modelscore=modelscore*thscore(i); % update the full model score to reflect
    
end

modelscore=modelscore^(1/Nth);
% after the loop, modelscore is calculated based on number of Th

% this part below draws the graphic flag with actual fates
% and draw the threshold lines on them
%set(0,'DefaultFigureVisible','off'); % suppresses the figure appearing when you run the script, still saves the plot file
flag = figure;
rectangle('position',[0,0,0.66,1]);
partition=1/length(seq);
x=[0 0 0.66 0.66];
for k=1:length(seq)
y=[1-k*partition 1-(k-1)*partition 1-(k-1)*partition 1-k*partition];    
fill(x,y,col(strcmp(InputFates(I(k)),FatesToTest),:),'linestyle','none');
hold on;
end
% a rectangle (flag) is divided into n parts, n being the number of cells
% tested in the model, for each partition,the real fates are called by k
% from the index of seq (I) and further called from InputFates. The
% resultant fate string is compared to FatesToTest to select color for
% filling. This way, a flag is drawn as using the tested model.

% this part below draws the threshold lines and tune up the final image
partorder=1:1:length(seq);
for kk=1:Nth
    plot([-0.2,0.86],[1-min(partorder(seq==Th(kk)))*partition,1-min(partorder(seq==Th(kk)))*partition],...
        '-','color','k','LineWidth',4);
    hold on;
end
title([modelname,' score=',num2str(round(100*modelscore)/100)],'FontSize',25);
axis off;

%savefigname = ['CurrentFigures/Fig/',modelname];
%saveepsname = ['CurrentFigures/EPS/',modelname];

%saveas(flag,savefigname,'fig');
%saveas(flag,saveepsname,'eps');

datastore={modelname,InputValues,Th,corrP,thscore,modelscore};

end