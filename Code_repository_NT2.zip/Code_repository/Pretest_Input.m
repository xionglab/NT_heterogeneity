
% this function prepares a matrix for Model_Test from a standard inputmatrx
% and a given criteria, it also takes in user specification of whether
% zeros are meaningful data or should simply be discarded. Model_Test
% finds zeros useful in some situations such as Time_Counter, other
% situations such as LMDV distance zeros are not useful
% 
function [Out,F]=Pretest_Input(InputMatrix,CleanFates,column,removezero)

for i=1:size(InputMatrix,3)
% column number
A=InputMatrix(:,:,i);
M=[A(:,1) A(:,column)];
F=CleanFates;

if removezero==1
    F=F(M(:,2)~=0);
    M=M(M(:,2)~=0,:);
end

Out(:,:,i)=M;

end

end