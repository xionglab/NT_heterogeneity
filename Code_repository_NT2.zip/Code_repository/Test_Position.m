
% this function tests and prints position models on all fates

function datastore=Test_Position(CleanFX_LMDVDistTrajs,TimeAxis,CleanFates,FatesToTest,col,modelname)

% output datastore is a table, rows are different attributes, columns are
% time points
FatesToTest = fliplr(FatesToTest);
n=length(TimeAxis);
datastore=cell(4,n+1);
datastore{2,1}='Th';
datastore{3,1}='corrP';
datastore{4,1}='score';

for ppp=2:n+1

    [N,F] = Pretest_Input(CleanFX_LMDVDistTrajs,CleanFates,ppp,1);
% select the kaede signal as the input
InputValues = N(:,:,1);
% cleanfates of the same dataset as in standard workspace
InputFates = F;
modelname2=[modelname,num2str(TimeAxis(ppp-1)),'hpf'];
% Run ModeTest as below to obtain a flag and other results
out=ModelTest_1(InputValues,InputFates,FatesToTest,col,modelname2);

datastore{1,ppp}=TimeAxis(ppp-1);
datastore{2,ppp}=out{1};
datastore{3,ppp}=out{2};
datastore{4,ppp}=out{3};


end
end


