

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% save all figures for draft viewing (jpg) and future editing (fig)

figHandles = findobj('Type','figure');
SimpleDataFileNames={'olig2','olig2_p','mnx1','shh_2'};
for hhh=1:length(figHandles)
    saveas(figHandles(hhh),[num2str(figHandles(hhh)),'_',SimpleDataFileNames{selector}],'fig');
    saveas(figHandles(hhh),[num2str(figHandles(hhh)),'_',SimpleDataFileNames{selector}],'jpg');
end