function SatCorrectData = SaturationMask_1(InputData,SatThresh)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Inputs %%%%%%%%%
% InputData - data matrix holding both the trajectories to be corrected for saturation, and their corresponding saturation data -  % assumes the first column of this is gofigure track id, that the time array is held separately (e.g. there are as many rows as gofigure track ids), when there is no data for tracks data is padded with zeros
% SatThresh - % of saturated voxels at which data for a mesh intensity
% estimation is consisered to be misestimated (underestimated) - e.g. a
% value of 0.1 means that all data points that were calculated from 10% or
% more saturated voxels are misestimated and will be thrown out
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%% Output  %%%%%%%%%%%%%%%%%%%%%%%%%%
% SatCorrectData - a matrix of the same structure but half the size in the third dimension as InputData; holds saturation corrected data for all signals in the dataset; for each channel of intensity trajectories, the appropriate saturation data is 
% referenced and the % of saturated voxels that went into each timepoint measurement for each trajectory is determined - for each trajectory, once the user 
% specified % saturation is reached at one timepoint, that timepoint and all subsequent timepoint data in that trajectory (for that channel) is considered 
% to be misestimated (underestimated), and is thrown out (set to zero)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

UnsatThresh = 1-SatThresh; % user inputs the % saturation at which data should be considered misestimated (e.g. 10% or above is entered as .1); actual data is % unsaturated voxels, so subtract from 1 to easily process

NoSignalsToCorrect = (size(InputData,3))/2; % the order of CleanStitchedTrajs in the third dimension is (signal 1 data, signal 2 data,...signal n data,signal 1 saturation, signal 2 saturation,...signal n saturation); first half is data, second half is saturation data 

% IntensityData and SatData are the same size - IntensityData is the first
% half of InputData (CleanStitchedTrajs) in the third dimension; SatData is
% the second half of InputData (CleanStitchedTrajs) in the third dimension
IntensityData = InputData(:,:,1:NoSignalsToCorrect); % initialize a new data matrix with the same format as original data, but half the size in the third dimension because it is only holding the *data* for all signals; 
SatData = InputData(:,:,NoSignalsToCorrect+1:size(InputData,3)); % initialize a new data matrix with the same format as original data, but half the size in the third dimension because it is only holding the *data* for all signals; 

SatCorrectData = InputData(:,:,1:NoSignalsToCorrect); % initialize a new data matrix with the same format as original data, but half the size in the third dimension because it is only holding the *data* for all signals; this will hold the saturation corrected data

for aa = 1:size(InputData,1)
    
    yPrelim = [];
    yPrelimSat = []; 
    
    yFinal = [];
    yFinalSat = [];
   
    
    % work with the intensity trajectory data for one gofigure id at a time
    for rrr = 1:NoSignalsToCorrect
    % for y data and y saturation data get rid of the first column which is the gofigure track id
    % yPrelim has as many rows as NoSignalsToCorrect and as many columns as number
    % of timepoints in dataset
    yPrelim(rrr,:) = IntensityData(aa,2:size(IntensityData,2),rrr);
    yPrelimSat(rrr,:) = SatData(aa,2:size(SatData,2),rrr);
    end
      
    % find the first and last nonzero elements in the trajectory data (the start
    % and end of the trajectory)
    [~,StartTraj] = find(yPrelim,1,'first');
    [~,EndTraj] = find(yPrelim,1,'last'); 
    
    %yFinal = yPrelim(:,StartTraj:EndTraj);
    yFinalSat = yPrelimSat(:,StartTraj:EndTraj);
    
    for sss = 1:NoSignalsToCorrect
           
    %yFinal(sss,:) = yPrelim(sss,StartTraj:EndTraj);
    yFinalSat(sss,:) = yPrelimSat(sss,StartTraj:EndTraj);
    
    FirstSatVal = find(yFinalSat(sss,:)<=UnsatThresh,1);  
     
    SatCorrectData(aa,StartTraj+FirstSatVal:EndTraj+1,sss) = 0;  
    
    FirstSatVal = [];
    
    end
    
    
        
end


