
function N=TimeCounter_1(StandardTrackMatrix,Th)
% Time point counter for thresholds
% the purpose of this function is to calculate, for each set of input tracks, how
% many time points were spent at a value above a certain threshold

% inputs: 1. StandardTrackMatrix - tracks starting with a track ID, followed by the values.
%         2. Threshold (Th) - a value

% outputs: N is a matrix of the same dimensions and rows as the input
% matrix, it only has two rows, row one is the trackIDs as the input, row
% two is the number of time points spent above the threshold

dim=size(StandardTrackMatrix,3);
row=size(StandardTrackMatrix,1);
N=StandardTrackMatrix;
N(:,3:end,:)=[];

for sss=1:dim
    for i=1:row
    N(i,2,sss)=sum(StandardTrackMatrix(i,2:end,sss)>Th);
    end
end
end
