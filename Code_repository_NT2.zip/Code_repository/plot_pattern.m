
function []=plot_pattern(InputMatrix,InputTime,PositionMatrix,PositionTime,whichsignal)

M=InputMatrix(:,2:end,whichsignal);
M=M(:,ismember(InputTime,PositionTime));
P=PositionMatrix(:,2:end);
P=P(:,ismember(PositionTime,InputTime));

% title
ftitle=['Spatial Pattern - signal ',num2str(whichsignal)];
fylabel='signal (A.U.)';
fxlabel='LMDV distance';
% labels

figure;
col=varycolor(size(P,2));
h=zeros(1,size(P,2));
flegends=cell(1,size(P,2));
for i=1:size(P,2)

signal1=P(:,i);
signal1(signal1==0)=NaN;
signal2=M(:,i);
signal2(signal2==0)=NaN;
h(i)=plot(signal1,signal2,'.','Color',col(i,:),'MarkerSize',10);
flegends{i}=[num2str(PositionTime(i)),' hpf'];

hold on;
end


axis tight

% Create title
title(ftitle,'FontSize',20);

% Create xlabel
xlabel(fxlabel,'FontSize',14);

% Create ylabel
ylabel(fylabel,'FontSize',14);

% Create legend
legend(h,flegends,'Position',[0.476485916474935 0.433993399339936 0.339285714285714 0.366666666666667]);

end
