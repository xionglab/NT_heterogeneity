function Deriv2Data = Deriv2Data_4(InputData,InputDataTime,dWindow)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Inputs %%%%%%%%%
% InputData - data matrix holding trajectories to be smoothed  -  % assumes the first column of this is gofigure track id, that the time array is held separately (e.g. there are as many rows as gofigure track ids), when there is no data for tracks data is padded with zeros
% DataTimeArray - row vector of timepoints corresponding to the data in InputData
% dWindow - number of time steps over which you want to take the second derivative
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%% Output  %%%%%%%%%%%%%%%%%%%%%%%%%%
% Deriv2Data - a matrix of the same size and structure as InputData, second
% derivative is calculated using a reverse window, and by iterating first derivative 2x; this means that the
% second derivative cannot be calculated for the first dWindow x2 timepoints, and
% the data values for these timepoints are set to zero
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Deriv2Data = InputData; % initialize a new data matrix with the same format as original data, this will hold the second deriv data


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xPrelim = InputDataTime;

time_interval = xPrelim(2)-xPrelim(1);
dWindowTime = dWindow*time_interval;

for rrr = 1:size(InputData,3)
    
for aa = 1:size(InputData,1)
    
   
    yPrelim = [];
    
    yFinal = [];
    
    yDeriv1 = [];
    
    yDeriv2 = [];
    
    % work with the intensity trajectory data for one gofigure id at a time
    
    % for y data get rid of the first column which is the gofigure track id
    % yPrelim has as many rows as NoOfSignals and as many columns as number
    % of timepoints in dataset
    yPrelim = InputData(aa,2:size(InputData,2),rrr);
    
    % find the first and last nonzero elements in the trajectory data (the start
    % and end of the trajectory)
    StartTraj = find(yPrelim,1,'first');
    EndTraj = find(yPrelim,1,'last');
    
    yFinal = yPrelim(StartTraj:EndTraj);
                
    yDeriv1 = zeros(1,size(yFinal,2)-dWindow);
    yDeriv2 = zeros(1,size(yFinal,2)-2*dWindow);
    
    for a = 1:size(yDeriv1,2)
            yDeriv1(a) = (yFinal(a+dWindow) - yFinal(a))/dWindowTime;
    end
        
    for a = 1:size(yDeriv2,2)
            yDeriv2(a) = (yDeriv1(a+dWindow) - yDeriv1(a))/dWindowTime;
    end
    
    Deriv2Data(aa,StartTraj+1:StartTraj+2*dWindow,rrr) = 0; % derivative is calculated over a reverse window so final derivative data for each trajectory will have 'dWindow' fewer timepoints of data on the front end than it has for the raw/smoothed data - replace that raw/smoothed data with zeros  
    Deriv2Data(aa,StartTraj+1+2*dWindow:EndTraj+1,rrr) = yDeriv2;
    
end
        
end

