% this function provides an estimate on the heterogeneity given any
% specified pair of cell types, the outputs are: number of single tracks of
% type1 being within the average+/- SD of type2 and vice versa, and number
% of single tracks of each type

function out=hetero(type1,type2,M,CleanFates,whichsignal,threshold)

out=zeros(2);

% obtain average tracks of each type and stdv
etrackID1=M(strcmp(CleanFates,type1));
   aveT1=AveTrack_1(M,etrackID1);
   aveT1(isnan(aveT1))=0;
   amean1=aveT1(1,2:end,whichsignal);
   astd1=aveT1(2,2:end,whichsignal);
etrackID2=M(strcmp(CleanFates,type2));
   aveT2=AveTrack_1(M,etrackID2);
   aveT2(isnan(aveT2))=0;
   amean2=aveT2(1,2:end,whichsignal);
   astd2=aveT2(2,2:end,whichsignal);
   
% judge if a track of type1 is within the SD of the average track of type2
% in the given time window, using a threshold timepoint criteria. i.e.,
% when threshold=0.5, it would mean that the single track is considered to
% be within the bound of the average track +/- SD during specified time
% window (do the windowing with the window function, not here) when more 
% than half of its time points have values within the SD.

for i=1:size(etrackID1,1)
    diff=abs(M(M(:,1,1)==etrackID1(i),2:end,whichsignal)-amean2);
    rec1(i)=sum(diff<astd2)/length(diff)>threshold;
end

for i=1:size(etrackID2,1)
    diff=abs(M(M(:,1,1)==etrackID2(i),2:end,whichsignal)-amean1);
    rec2(i)=sum(diff<astd1)/length(diff)>threshold;
end
% record output
out(1,1)=sum(rec1);
out(1,2)=size(etrackID1,1);
out(2,1)=sum(rec2);
out(2,2)=size(etrackID2,1);

end