
% test speed models, forwards and backwards

% specify times (HPF)
t1=12;
t2=15;

% forwards
FatesToTest = {'LFP' 'MN' 'DorsalToMN'};
colf=flipud([0 0 1;0 1 0;0.87058824300766,0.490196079015732,0]);
modelname = 'Cell Speed v-d ';

N=CellSpeed(Clean_X_StitchedTrajs,Clean_Y_StitchedTrajs,...
    Clean_Z_StitchedTrajs,TimePointArrayHPF,3);
Test(N,TimePointArrayHPF,CleanFates,FatesToTest,colf,t1,1,modelname);
Test(N,TimePointArrayHPF,CleanFates,FatesToTest,colf,t2,1,modelname);


% backwards
FatesToTest = fliplr({'LFP' 'MN' 'DorsalToMN'});
colf=[0 0 1;0 1 0;0.87058824300766,0.490196079015732,0];

modelname = 'Cell Speed d-v ';

N=CellSpeed(Clean_X_StitchedTrajs,Clean_Y_StitchedTrajs,...
    Clean_Z_StitchedTrajs,TimePointArrayHPF,3);
Test(N,TimePointArrayHPF,CleanFates,FatesToTest,colf,t1,1,modelname);
Test(N,TimePointArrayHPF,CleanFates,FatesToTest,colf,t2,1,modelname);


