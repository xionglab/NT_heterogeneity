
% this function finds the time coordinate in the TimePoint arrays given certain
% range of values in the standard traj matrix

function NT=FindTime_1(StandardMatrix,TimePointArrayHFP,lower,upper)

% Input: StandardMatrix of tracks and corresponding Time array
% lower and upper bounds of the range to look for

% Output: NT is a Cell matrix using the Standardmatrix format, the values
% in the first column will be the trackIDs, the second colum will be
% vectors that contain the time points when values within the range were
% found for that track.

row=size(StandardMatrix,1);
dim=size(StandardMatrix,3);
NT=cell(row,2,dim);

for j=1:dim;
    for i=1:row;
    NT{i,1,j}=StandardMatrix(i,1,j);
    V=StandardMatrix(i,2:end,j);
    ind=V>lower & V<=upper;
    T=TimePointArrayHFP(ind);
    NT{i,2,j}=T;
    end
end
    
    
    