function Tdis=plot_timedistribution(PP,TT,TimeRanges,ValueRanges,CleanFates,FatesToPlot,col,whichsignal)

% this script plots the distribution of values on the specified time axis,
% showing the temporal change of certain events

% specify the inputs for FindTime function
InputMatrix=PP;
InputTimeArray=TT;

Tdis=DisTime_1(InputMatrix,InputTimeArray,ValueRanges,TimeRanges,whichsignal);

% the plotting will be an elaboration of plot_times_3, now splitting into
% different time windows

for k=1:size(TimeRanges,1)
% Create figure
figure;

for i=1:size(ValueRanges,1)
subplot(1,size(ValueRanges,1),i)

% the cell array to store input for tony script
tony=FatesToPlot;
for j=1:size(FatesToPlot,2)
    index=strcmp(CleanFates,FatesToPlot(j));
    M=Tdis(index,:,i);
    tony{j}=M(:,k+1);
end

mycolorscatterplot1d(tony,col,1);

% Create title
title([num2str(ValueRanges(i,1)),'<Signal ',num2str(whichsignal),'<',num2str(ValueRanges(i,2)),...
    ' between ',num2str(TimeRanges(k,1)),' and ',num2str(TimeRanges(k,2)),'hpf']);
% Create xlabel
xlabel('Cell Types');
% Create ylabel
ylabel('Number of Time points');
% set y axis for comparison
ylim([0 12]);

end

end
end