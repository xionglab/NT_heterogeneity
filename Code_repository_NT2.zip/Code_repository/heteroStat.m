
% heterogeneity stats for each data set
whichsignal=1;
th=0.5;
s1=hetero('MN','LFP',M0,CleanFates,whichsignal,th);
s2=hetero('MN','DorsalToMN',M0,CleanFates,whichsignal,th);
s3=hetero('LFP','DorsalToMN',M0,CleanFates,whichsignal,th);
s4=hetero('LFP','LFP',M0,CleanFates,whichsignal,th);
s5=hetero('MN','MN',M0,CleanFates,whichsignal,th);
s6=hetero('DorsalToMN','DorsalToMN',M0,CleanFates,whichsignal,th);

%
hets=[s1,s2,s3,s4,s5,s6];