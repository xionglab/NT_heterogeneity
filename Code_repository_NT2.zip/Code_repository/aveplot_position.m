% this plots the average tracks by fate, could be used for other purposes
% Use aveplot_2 for intensities, which includes shades
% use this one for positions

function []=aveplot_position(CleanFX_LMDVDistTrajs,NotocordTimesArrayHPF,CleanFates,...
    FatesToPlot,col)

InputStandardMatrix=CleanFX_LMDVDistTrajs;
% change this to make plots for others such as position
InputTimeVector=NotocordTimesArrayHPF;
whichsignal = 1;

% for position, unnote the next line
label='LM-DV Distance (\mum)';

etrackID1=InputStandardMatrix(strcmp(CleanFates,FatesToPlot(1)));
etrackID2=InputStandardMatrix(strcmp(CleanFates,FatesToPlot(2)));
etrackID3=InputStandardMatrix(strcmp(CleanFates,FatesToPlot(3)));
etrackID4=InputStandardMatrix(strcmp(CleanFates,FatesToPlot(4)));

aveT1=AveTrack_1(InputStandardMatrix,etrackID1);
aveT2=AveTrack_1(InputStandardMatrix,etrackID2);
aveT3=AveTrack_1(InputStandardMatrix,etrackID3);
aveT4=AveTrack_1(InputStandardMatrix,etrackID4);


% Create figure
figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1,...
    'Position',[0.13 0.11 0.658433382137628 0.810792079207921],...
    'FontSize',12);
xlim(axes1,[round(min(InputTimeVector)-0.5) round(max(InputTimeVector)+0.5)]);
ylim(axes1,[0 max(aveT4(1,:,whichsignal)+aveT4(2,:,whichsignal))]);
hold on;
errorbar(InputTimeVector,aveT1(1,2:end,whichsignal),aveT1(2,2:end,whichsignal),'LineWidth',2,...
    'DisplayName',['MFP (n=',num2str(length(etrackID1)),')'],...
    'Color',col(1,:));
hold on;
errorbar(InputTimeVector,aveT2(1,2:end,whichsignal),aveT2(2,2:end,whichsignal),'LineWidth',2,...
    'DisplayName',['LFP (n=',num2str(length(etrackID2)),')'],...
    'Color',col(2,:));
hold on;
errorbar(InputTimeVector,aveT3(1,2:end,whichsignal),aveT3(2,2:end,whichsignal),'LineWidth',2,...
    'DisplayName',['pMN (n=',num2str(length(etrackID3)),')'],...
    'Color',col(3,:));
hold on;
errorbar(InputTimeVector,aveT4(1,2:end,whichsignal),aveT4(2,2:end,whichsignal),'LineWidth',2,...
    'DisplayName',['More dorsal (n=',num2str(length(etrackID4)),')'],...
    'Color',col(4,:));

% Create title
title('Average Tracks','FontSize',20);

% Create xlabel
xlabel('Time (hpf)','FontSize',14);

% Create ylabel
ylabel(label,'FontSize',14);

% Create legend
legend1 = legend(axes1,'show');
set(legend1,...
    'Position',[0.476485916474935 0.433993399339936 0.339285714285714 0.366666666666667]);
end
