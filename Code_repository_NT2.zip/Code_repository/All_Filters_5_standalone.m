
% this script collects all filters and run through them with easily defined
% parameters to the derivatives

% this mainly concerns intensity analysis, not position or division
% select dataset here

DatasetFile='NewFinalWrkSpace_olig2_9.mat';
ProcessingSaveFile='All_Filters_olig2_9.mat';

load(DatasetFile);
%load(ProcessingSaveFile);

% Inputs
InputMatrix=CleanStitchedTrajs;
InputTimeArray=TimePointArrayHPF;

% Saturation Correction mask threshold (0~1)
satmask=0.25;
% Bleedthrough correction coefficients will be determined by the function
% Smoothing window and number of iterations
winsmo=3;
iteration=2;
% Derivative windows
windv1=3;
windv2=3;
% data windowing for final processing
t1=10;
t2=15;
% create an array to collect the parameters
% and save it to be associated with the final results
FilterParameters={'satmask',satmask;'smoothing',...
    [winsmo,iteration];'derivatives',[windv1,windv2];'windowing',[t1,t2]};
%save(ProcessingSaveFile,'InputMatrix','InputTimeArray','FilterParameters','-append');
save(ProcessingSaveFile,'InputMatrix','InputTimeArray','FilterParameters');

% correct saturation and save
M1=SaturationMask_1(InputMatrix,satmask); 
save(ProcessingSaveFile,'M1','-append');

% correct bleedthrough and save
M2=BleedthroughCorr_2(M1); 
save(ProcessingSaveFile,'M2','-append');

% smooth and save
for i=1:iteration
M2=SmoothData_6(M2,winsmo); % in order to be able to call the smoothing function multiple times and have it iterate correctly, don't iterate M2 to M3 here - do this after all smoothing iterations are called
end
M3 = M2;
save(ProcessingSaveFile,'M3','-append');

% normalize to 1 AU and save
M4=NormalizeData_1(M3,1);
save(ProcessingSaveFile,'M4','-append');

% derivative 1 and 2
M4_d1=Deriv1Data_8(M4,InputTimeArray,windv1); save(ProcessingSaveFile,'M4_d1','-append');
M4_d2=Deriv2Data_4(M4,InputTimeArray,windv2); save(ProcessingSaveFile,'M4_d2','-append');

% Window all data to keep only data between t1 and t2 (hpf);
% this step cleans low density / noisy tracks on both ends of the datasets
[M0,M0TimeAxis]=WindowData_3(M4,InputTimeArray,t1,t2);
[M0_d1,M0TimeAxis]=WindowData_3(M4_d1,InputTimeArray,t1,t2);
[M0_d2,M0TimeAxis]=WindowData_3(M4_d2,InputTimeArray,t1,t2);

save(ProcessingSaveFile,'M0','-append');
save(ProcessingSaveFile,'M0_d1','-append');
save(ProcessingSaveFile,'M0_d2','-append');
save(ProcessingSaveFile,'M0TimeAxis','-append');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Use a transcription model - with known RNA half lives, perform a
% transform, half live has unit of hours
halflife=3;
k=log(2)/halflife;
PP=M0_d1.*k+M0_d2;
TT=M0TimeAxis;
save(ProcessingSaveFile,'halflife','-append');
save(ProcessingSaveFile,'PP','-append');
save(ProcessingSaveFile,'TT','-append');
% PP and TT mean the modeled matrix and time axis, respectively


% In the end, clear and reload the final workspace and data generated between these
% steps
clearvars -except DatasetFile ProcessingSaveFile selector;
load(DatasetFile);
load(ProcessingSaveFile);
