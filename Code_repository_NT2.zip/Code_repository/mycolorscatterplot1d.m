function out=mycolorscatterplot1d(M,col,stat,symmetric)
% a comparative plot using individual values as dots 
% each condition is one cell in M
% col is a matrix of representing color in RGB
% stat = 1 plot mean and std
% stat = 2 plot median and quartile
% stat = 3 plot mean and s.e.m.
% stat =4 box plot with whisker = 25% and 75% with one IQR
% nargin = 4 means plot symmetrically

% 2013-Jan-2 put in a code to remove NaN;
for j=1:length(M)
    M{j}=M{j}(~isnan(M{j}));
end

width=0.3;
for j=1:length(M)
    if nargin==4
        if symmetric 
        % 2013-Jan-4 put in a code to change the x coordinate so that it is
        % symmetric
        clear xcoordinate
        Mindex=unique(M{j});
        for k=1:length(Mindex)
            ind=find(M{j}==Mindex(k));
            nind=length(ind);
            if nind>7
                for n=1:nind
                    xcoordinate(ind(n))=j-width+(n-1)*2*width/(nind-1);
                end
            elseif rem(nind,2)==0
                for n=1:nind
                    xcoordinate(ind(n))=j-0.05-0.1*(nind/2-1)+(n-1)*0.1;
                end
            else
                for n=1:nind
                    xcoordinate(ind(n))=j-0.1*(nind-1)/2+(n-1)*0.1;
                end                
            end
        end
        else
         xcoordinate=NaN(size(M{j}));   
        end
    else
        xcoordinate=j-0.3+0.6*rand(size(M{j}));
    end
    hold on
    plot(xcoordinate,M{j},'.','Color',col(j,:),'MarkerSize',15);
end
if stat==1
    for j=1:length(M)
        plot(j-0.3:0.1:j+0.3,ones(1,7)*mean(M{j}),'-','color','k','LineWidth',2);
        plot(j-0.1:0.1:j+0.1,ones(1,3)*(mean(M{j})+std(M{j})),'-','color','k','LineWidth',2);
        plot(j-0.1:0.1:j+0.1,ones(1,3)*(mean(M{j})-std(M{j})),'-','color','k','LineWidth',2);
        plot([j,j],mean(M{j})+std(M{j})*[-1,1],'-','color','k','LineWidth',2);
    end
elseif stat==2
    for j=1:length(M)
        plot(j-0.3:0.1:j+0.3,ones(1,7)*median(M{j}),'-','color','k','LineWidth',2);
        plot(j-0.1:0.1:j+0.1,ones(1,3)*quantile(M{j},0.25),'-','color','k','LineWidth',2);
        plot(j-0.1:0.1:j+0.1,ones(1,3)*quantile(M{j},0.75),'-','color','k','LineWidth',2);
        plot([j,j],[quantile(M{j},0.25),quantile(M{j},0.75)],'-','color','k','LineWidth',2);
    end
elseif stat==3
    for j=1:length(M)
        plot(j-0.3:0.1:j+0.3,ones(1,7)*mean(M{j}),'-','color','k','LineWidth',2);
        plot(j-0.1:0.1:j+0.1,ones(1,3)*(mean(M{j})+std(M{j})/sqrt(length(M{j}))),'-','color','k','LineWidth',2);
        plot(j-0.1:0.1:j+0.1,ones(1,3)*(mean(M{j})-std(M{j})/sqrt(length(M{j}))),'-','color','k','LineWidth',2);
        plot([j,j],mean(M{j})+std(M{j})*[-1,1]/sqrt(length(M{j})),'-','color','k','LineWidth',2);
    end
elseif stat ==4
    for j=1:length(M)
        plot(j-0.3:0.1:j+0.3,ones(1,7)*median(M{j}),'-','color',col(j,:),'LineWidth',1);
        plot(j-0.3:0.1:j+0.3,ones(1,7)*quantile(M{j},0.25),'-','color',col(j,:),'LineWidth',1);
        plot(j-0.3:0.1:j+0.3,ones(1,7)*quantile(M{j},0.75),'-','color',col(j,:),'LineWidth',1);
        plot([j-0.3,j-0.3],[quantile(M{j},0.25),quantile(M{j},0.75)],'-','color',col(j,:),'LineWidth',1);
        plot([j+0.3,j+0.3],[quantile(M{j},0.25),quantile(M{j},0.75)],'-','color',col(j,:),'LineWidth',1);
        IQR=quantile(M{j},0.75)-quantile(M{j},0.25);
        topwhisk=max(M{j}(M{j}<quantile(M{j},0.75)+1.5*IQR));
        lowwhisk=min(M{j}(M{j}>quantile(M{j},0.25)-1.5*IQR));
        plot([j,j],[quantile(M{j},0.75) topwhisk],'--','color',col(j,:),'LineWidth',1);
        plot([j,j],[quantile(M{j},0.25) lowwhisk],'--','color',col(j,:),'LineWidth',1);
        plot([j-0.1,j+0.1],topwhisk*[1,1],'color',col(j,:),'LineWidth',1);
        plot([j-0.1,j+0.1],lowwhisk*[1,1],'color',col(j,:),'LineWidth',1);
        topoutlier=M{j}(M{j}>quantile(M{j},0.75)+1.5*IQR);
        lowoutlier=M{j}(M{j}<quantile(M{j},0.25)-1.5*IQR);
        % these plotting commands will duplicate the outliers
        %plot(j-0.1+0.2*rand(1,length(topoutlier)),topoutlier,'.','color',col(j,:),'LineWidth',1); %
        %plot(j-0.1+0.2*rand(1,length(lowoutlier)),lowoutlier,'.','color',col(j,:),'LineWidth',1);
    end
end
set(gca,'XTickLabel','')
out=[];
%legend(co