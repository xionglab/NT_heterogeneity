
function plot_ave(PP,TT,CleanFates,FatesToPlot,col,whichsignal)

% This script plots the average results by fate
% using tony's error bar scatter
% needs CleanFates from the standard workspace and output of Max 

% Run AveVal to get the output matrix
AveVal=AveVal_1(PP);
TimeAxis=TT;

% Create figure
figure1 = figure;
% Create axes
axes1 = axes('Parent',figure1);
xlim(axes1,[0.5 4.5]);
% ylim(axes1,[0 40]);
box(axes1,'on');
hold(axes1,'all');
title(axes1,['Transient Reporter Output Signal ',num2str(whichsignal)]);

% the cell array to store input for tony script
tony=FatesToPlot;
for i=1:size(FatesToPlot,2)
    index=strcmp(CleanFates,FatesToPlot(i));
    M=AveVal(index,:,whichsignal);
    tony{i}=M(:,2);
end

mycolorscatterplot1d(tony,col,1);

% Create xlabel
xlabel('Cell Types');
% Create ylabel
ylabel(['Average Value over ',num2str(min(TimeAxis)),' and ',num2str(max(TimeAxis))]);

end