
% this function generates the input matrix of division times

function N = DivisionTime(M,DivId)

N=M(:,1:2,1);
N(:,2)=0;
for i=1:size(DivId,1)
    ind=N(:,1)==DivId(i,7);
    if max(ind)==1
    N(ind,2)=DivId(i,11);
    end
end
end
