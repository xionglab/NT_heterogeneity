
% Status: Proposed to Accept
% Use: generate a plot or multiple plots of user specified single tracks
% Purpose: data interaction
% Inputs:
%   User specify: trackID ---Array of GoFigure IDs designating the tracks
% to plot // whichSignal ---1=kaede only, 2=gfp only, 3=both
%   From Standard WorkSpace: TimePointArrayHPF // CleanStitchedTrajs // CleanFates

% Example usage (copy to run): 
% multiplot(CleanStitchedTrajs(:,1,1),3,TimePointArrayHPF,CleanStitchedTrajs,CleanFates);

function []=multiplot(trackID,whichSignal,TimePointArrayHPF,CleanStitchedTrajs,CleanFates)

figure

if whichSignal==3
for i=1:length(trackID)
subplot(round(sqrt(length(trackID))),round(sqrt(length(trackID))+0.5),i);
row=CleanStitchedTrajs(:,1,1)==trackID(i);
plot(TimePointArrayHPF,CleanStitchedTrajs(row,2:end,1),'r');
hold on;
plot(TimePointArrayHPF,CleanStitchedTrajs(row,2:end,2),'g');
axis([TimePointArrayHPF(1),TimePointArrayHPF(end),0,max(max(max(CleanStitchedTrajs(:,2:end,:))))]);
title(['ID=',num2str(trackID(i)),'(',char(CleanFates(row)),')']);
end

elseif whichSignal==1 || 2
    for i=1:length(trackID)
subplot(round(sqrt(length(trackID))),round(sqrt(length(trackID))+0.5),i);
row=CleanStitchedTrajs(:,1,1)==trackID(i);
plot(TimePointArrayHPF,CleanStitchedTrajs(row,2:end,whichSignal),'b');
axis([TimePointArrayHPF(1),TimePointArrayHPF(end),0,max(max(CleanStitchedTrajs(:,2:end,whichSignal)))]);
title(['ID=',num2str(trackID(i)),'(',char(CleanFates(row)),')']);
    end
end