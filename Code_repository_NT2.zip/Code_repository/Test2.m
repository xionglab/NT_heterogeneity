
% this function tests value models with time point information
% differing from Test, this one tests signal 2

% input explanation:
% N: Input matrix in standard format, such as CleanStitchedTrajs,
% CleanFX_LMDVDistTrajs
% TT: Time Axis (or essentially any column label) corresponding to the
% Input matrix, such as TimePointArrayHPF, if not needed, input "0"
% CleanFates: Fate cell array as in standard workspace
% FatesToTest: cell array selecting fates to test, Note: follow a 
% descending order as predicted by the model to be tested
% col: colors corresponding to the fates to test, in the same order
% T: if TT is used, the Time to be tested, which should be found in TT, 
% if TT was NOT used, T should be the column number for N, e.g., 2,30
% removezero: Are the zeros encountered in the matrix relevent for model
% testing? or are they just indicating no data and should not be tested?
% Use 1 for removingzero, 0 for keeping them
% modelname: a string to be printed on the flag, specify for each test.

% output explanation
% datastore records the algorithm-found thresholds (Th) between each fate 
% tested, the percentage of correct prediction using that Th (corrP), and a
% score defined in ModelTest_1 function.

function datastore=Test2(N,TT,CleanFates,FatesToTest,col,T,removezero,modelname)

column=T;
if size(TT,2)>1
column=find(TT==T);
end
[N,F] = Pretest_Input(N,CleanFates,column,removezero);
% select the gfp signal as the input
InputValues = N(:,:,2);
% cleanfates of the same dataset as in standard workspace
InputFates = F;

% Run ModeTest as below to obtain a flag and other results
datastore=ModelTest_1_art(InputValues,InputFates,FatesToTest,col,modelname);
end