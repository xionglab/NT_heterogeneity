
% this function calculates the distribution of time points across the time
% axis for each track, the values of the input matrix at the time points
% are within specified ranges

% Note: this function requires the sub-function of FindTime

function Tdis=DisTime_1(InputMatrix,InputTimeArray,ValueRanges,TimeRanges,whichsignal)

% Inputs: ValueRanges: mX2 matrix, row 1 is the lower bound row 2 is the upper
% bound; TimeRanges: nX2 matrix, row 1 is the earlier time and row 2 is the
% later time.

% Output: Tdis has dimension 1 equal to Inputmatrix, dimension 2 is n+1,
% the extra column stores the trackIDs. other columns store n sections of
% time ranges. dimension 3 is m.

Tdis=zeros(size(InputMatrix,1),size(TimeRanges,1)+1,size(ValueRanges,1));

% Calculation starts here
for k=1:size(ValueRanges,1)
NT=FindTime_1(InputMatrix,InputTimeArray,ValueRanges(k,1),ValueRanges(k,2));
% this yields the located time points for range(k)
    for i=1:size(NT,1)
    VT=NT{i,2,whichsignal};
    Tdis(i,1,k)=InputMatrix(i,1,1);
        for j=1:size(TimeRanges,1)
            Tdis(i,j+1,k)=sum(VT>TimeRanges(j,1) & VT<=TimeRanges(j,2));
        end
    end
end
