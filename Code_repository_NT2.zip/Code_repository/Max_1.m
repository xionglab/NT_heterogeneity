


function M=Max_1(StandardTrackMatrix)
% this function grabs the maximum value from a set of tracks and return a
% matrix M

% inputs: 1. StandardTrackMatrix - tracks starting with a track ID, followed by the values.

% outputs: M is a matrix of the same dimensions and rows as the input
% matrix, it only has two columns, column one is the trackIDs as the input,
% column two is maximum value found in that track

dim=size(StandardTrackMatrix,3);
row=size(StandardTrackMatrix,1);
M=StandardTrackMatrix;
M(:,3:end,:)=[];

for sss=1:dim
    for i=1:row
    M(i,2,sss)=max(StandardTrackMatrix(i,2:end,sss));
    end
end
end