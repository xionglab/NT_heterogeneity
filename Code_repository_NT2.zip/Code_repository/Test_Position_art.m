
% this function tests and prints position models on all fates

function datastore=Test_Position_art(CleanFX_LMDVDistTrajs,TimeAxis,CleanFates,FatesToTest,col,modelname)

% output datastore is a table, rows are timepoints at which LMDV position data can be calculated, columns are different model attributes

FatesToTest = fliplr(FatesToTest);
n=length(TimeAxis);
datastore=cell(n,7);

for ppp=2:n+1

    [N,F] = Pretest_Input(CleanFX_LMDVDistTrajs,CleanFates,ppp,1);
% select the position measure at current tp as the input
InputValues = N(:,:,1);
% cleanfates of the same dataset as in standard workspace
InputFates = F;
modelname2=[modelname,num2str(TimeAxis(ppp-1)),'hpf'];
% Run ModelTest as below to obtain a flag and other results
out = ModelTest_1_art(InputValues,InputFates,FatesToTest,col,modelname2);

datastore{ppp-1,1}=out{1};
datastore{ppp-1,2}=out{2};
datastore{ppp-1,3}=out{3};
datastore{ppp-1,4}=out{4};
datastore{ppp-1,5}=out{5};
datastore{ppp-1,6}=out{6};
datastore{ppp-1,7}=TimeAxis(ppp-1);


end
end


