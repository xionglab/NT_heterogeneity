
% Define fates to be plotted here and signals to be plotted
FatesToPlot = {'LFP' 'MN' 'DorsalToMN'};
plotnames = {'LFP' 'pMN' 'More dorsal'};
col=[0.87058824300766,0.490196079015732,0;0 1 0;0 0 1];
% colors