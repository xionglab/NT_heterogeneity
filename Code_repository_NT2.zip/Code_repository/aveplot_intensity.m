function []=aveplot_intensity(CleanStitchedTrajs,TimePointArrayHPF,CleanFates,FatesToPlot,fatecolor,plotnames,whichsignal)

% this plots the average tracks by fate, could be used for other purposes
% use shading for errorbars to increase presentation quality

% ------specify inputs------
InputStandardMatrix=CleanStitchedTrajs;
InputTimeVector=TimePointArrayHPF;
% change this to make plots for others such as position

% ------specify which fates to plot and style and labels------
%FatesToPlot = {'MFP' 'LFP' 'MN' 'DorsalToMN'};
%fatecolor = [1,0,0;0.87058824300766,0.490196079015732,0;0 1 0;0 0 1];
%plotnames = {'MFP' 'LFP' 'pMN' 'More dorsal'};
% these can be better aggregated to make more modular

% ------specify which signal to plot, title and the x,y axis label------
%whichsignal = 1;
% plot GFP, use whichsignal=2
% plot kaede, use whichsignal=1
% title
ftitle='Average Tracks';
% x label
fxlabel='Time (hpf)';
% y label
if whichsignal==1
    fylabel='Tg(ptch2:kaede) Kaede Intensity (A.U.)';
elseif whichsignal==2
    fylabel='GFP Intensity (A.U.)';
end
% for position, unnote the next line
% fylabel='LM-DV Distance (\mum)';
% for transcription, unnote the next line
% fylabel='Transcription Rate';

% ------specify x and y ranges------
xrange=[min(InputTimeVector) max(InputTimeVector)];
yrange=[0 1];

% ------specify style of error bar shades
alpha=0.5;

% Starting processing and plotting here
% Note: need custom function AveTrack

% Create figure
figure1 = figure;

% Create axes
axes1 = axes('Parent',figure1,...
    'Position',[0.13 0.11 0.658433382137628 0.810792079207921]);

h=zeros(1,size(FatesToPlot,2));
flegends=cell(1,size(FatesToPlot,2));
for i=1:size(FatesToPlot,2)
   etrackID=InputStandardMatrix(strcmp(CleanFates,FatesToPlot(i)));
   aveT=AveTrack_1(InputStandardMatrix,etrackID);
    h(i)=plot(InputTimeVector,aveT(1,2:end,whichsignal),'LineWidth',2,...
    'DisplayName',[plotnames{i},' (n=',num2str(length(etrackID)),')'],...
    'Color',fatecolor(i,:));
    flegends{i}=[plotnames{i},' (n=',num2str(length(etrackID)),')'];
    hold on;
    aveT(isnan(aveT))=0;
    amean=aveT(1,2:end,whichsignal);
    astd=aveT(2,2:end,whichsignal);
    fill([InputTimeVector fliplr(InputTimeVector)],[amean+astd fliplr(amean-astd)],fatecolor(i,:),...
    'FaceAlpha', alpha,'linestyle','none');
    hold on;
end

% set axis format and ranges
xlim(axes1,xrange);
ylim(axes1,yrange);
set(gca,'YAxisLocation','left');
set(gca,'box','off');
set(gca,'FontSize',12,'LineWidth',2);

% Create title
title(ftitle,'FontSize',20);

% Create xlabel
xlabel(fxlabel,'FontSize',14);

% Create ylabel
ylabel(fylabel,'FontSize',14);

% Create legend
legend(h,flegends,'Position',[0.155057345046364 0.682406097752634 0.339285714285714 0.207936507936508]);

end
